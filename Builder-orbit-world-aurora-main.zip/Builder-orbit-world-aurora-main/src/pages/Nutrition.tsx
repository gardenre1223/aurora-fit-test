import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Apple,
  Plus,
  TrendingUp,
  Target,
  Clock,
  Users,
  Calendar,
  Utensils,
  ChefHat,
  BarChart3,
  Droplet,
  Zap,
} from "lucide-react";
import { authManager, getUserPermissions } from "@/lib/auth";

const Nutrition = () => {
  const [isCreatePlanDialogOpen, setIsCreatePlanDialogOpen] = useState(false);
  const [isLogMealDialogOpen, setIsLogMealDialogOpen] = useState(false);
  const user = authManager.getCurrentUser();
  const permissions = user ? getUserPermissions(user.role) : null;

  if (!user) return null;

  const isAdmin = user.role === "administrator";
  const isCoach = user.role === "coach";
  const isUser = user.role === "user";

  // Mock nutrition data
  const nutritionStats = [
    {
      title: isCoach ? "Planes Activos" : "Calorías Hoy",
      value: isCoach ? "12" : "1,850",
      target: isCoach ? "" : "/ 2,200",
      change: "+5%",
      icon: isCoach ? Users : Zap,
    },
    {
      title: isCoach ? "Consultas Programadas" : "Proteína",
      value: isCoach ? "8" : "125g",
      target: isCoach ? "" : "/ 150g",
      change: "+8%",
      icon: isCoach ? Calendar : ChefHat,
    },
    {
      title: isCoach ? "Planes Creados" : "Agua",
      value: isCoach ? "15" : "2.1L",
      target: isCoach ? "" : "/ 3L",
      change: "+12%",
      icon: isCoach ? Target : Droplet,
    },
    {
      title: "Adherencia",
      value: "92%",
      target: "",
      change: "+3%",
      icon: TrendingUp,
    },
  ];

  const mealPlans = [
    {
      id: 1,
      name: "Plan de Definición",
      description: "Enfoque en pérdida de grasa manteniendo masa muscular",
      calories: "2,200 kcal/día",
      duration: "8 semanas",
      meals: 5,
      coach: "Dr. Ana Ruiz",
      status: "active",
      progress: 75,
    },
    {
      id: 2,
      name: "Plan de Volumen",
      description: "Aumento de masa muscular con superávit calórico",
      calories: "3,200 kcal/día",
      duration: "12 semanas",
      meals: 6,
      coach: "Lic. María Pérez",
      status: "completed",
      progress: 100,
    },
  ];

  const todayMeals = [
    {
      id: 1,
      name: "Desayuno",
      time: "08:00",
      foods: ["Avena con frutas", "Proteína whey", "Almendras"],
      calories: 420,
      completed: true,
    },
    {
      id: 2,
      name: "Media Mañana",
      time: "10:30",
      foods: ["Yogurt griego", "Nueces"],
      calories: 180,
      completed: true,
    },
    {
      id: 3,
      name: "Almuerzo",
      time: "13:00",
      foods: ["Pollo a la plancha", "Arroz integral", "Ensalada mixta"],
      calories: 650,
      completed: false,
    },
    {
      id: 4,
      name: "Merienda",
      time: "16:00",
      foods: ["Batido de proteínas", "Banana"],
      calories: 300,
      completed: false,
    },
    {
      id: 5,
      name: "Cena",
      time: "20:00",
      foods: ["Salmón", "Vegetales al vapor", "Quinoa"],
      calories: 550,
      completed: false,
    },
  ];

  const consultations = [
    {
      id: 1,
      client: isCoach ? "Carlos Mendoza" : undefined,
      nutritionist: isCoach ? undefined : "Dr. Ana Ruiz",
      date: "2024-01-16",
      time: "10:00",
      type: "Seguimiento",
      status: "scheduled",
    },
    {
      id: 2,
      client: isCoach ? "Sofia López" : undefined,
      nutritionist: isCoach ? undefined : "Lic. María Pérez",
      date: "2024-01-18",
      time: "15:00",
      type: "Evaluación inicial",
      status: "scheduled",
    },
  ];

  const totalCalories = todayMeals.reduce(
    (sum, meal) => sum + meal.calories,
    0,
  );
  const consumedCalories = todayMeals
    .filter((meal) => meal.completed)
    .reduce((sum, meal) => sum + meal.calories, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <Apple className="h-8 w-8 text-aurora-primary" />
            Nutrición
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            {isAdmin
              ? "Gestiona todos los planes nutricionales del sistema"
              : isCoach
                ? "Crea y monitorea planes alimenticios de tus clientes"
                : "Tu alimentación y planes nutricionales personalizados"}
          </p>
        </div>
        <div className="flex gap-2">
          {!isUser && (
            <Dialog
              open={isCreatePlanDialogOpen}
              onOpenChange={setIsCreatePlanDialogOpen}
            >
              <DialogTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Crear Plan
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Crear Plan Nutricional</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Cliente</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="carlos">Carlos Mendoza</SelectItem>
                        <SelectItem value="sofia">Sofia López</SelectItem>
                        <SelectItem value="ana">Ana Martínez</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Objetivo</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Objetivo nutricional" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="perdida">Pérdida de peso</SelectItem>
                        <SelectItem value="volumen">Aumento de masa</SelectItem>
                        <SelectItem value="mantenimiento">
                          Mantenimiento
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Calorías diarias</Label>
                    <Input placeholder="ej. 2200" />
                  </div>
                  <Button
                    className="w-full aurora-button-primary"
                    onClick={() => setIsCreatePlanDialogOpen(false)}
                  >
                    Crear Plan
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
          <Dialog
            open={isLogMealDialogOpen}
            onOpenChange={setIsLogMealDialogOpen}
          >
            <DialogTrigger asChild>
              <Button className="aurora-button-primary gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
                <Plus className="h-4 w-4" />
                {isUser ? "Registrar Comida" : "Nueva Consulta"}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {isUser ? "Registrar Comida" : "Programar Consulta"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                {isUser ? (
                  <>
                    <div>
                      <Label>Tipo de comida</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="desayuno">Desayuno</SelectItem>
                          <SelectItem value="almuerzo">Almuerzo</SelectItem>
                          <SelectItem value="cena">Cena</SelectItem>
                          <SelectItem value="merienda">Merienda</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Alimentos</Label>
                      <Input placeholder="ej. Pollo a la plancha, Arroz..." />
                    </div>
                    <div>
                      <Label>Calorías estimadas</Label>
                      <Input placeholder="ej. 450" />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <Label>Cliente</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar cliente" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="carlos">Carlos Mendoza</SelectItem>
                          <SelectItem value="sofia">Sofia López</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Tipo de consulta</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="inicial">
                            Evaluación inicial
                          </SelectItem>
                          <SelectItem value="seguimiento">
                            Seguimiento
                          </SelectItem>
                          <SelectItem value="revision">
                            Revisión de plan
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Fecha y hora</Label>
                      <Input type="datetime-local" />
                    </div>
                  </>
                )}
                <Button
                  className="w-full gym-button-primary"
                  onClick={() => setIsLogMealDialogOpen(false)}
                >
                  {isUser ? "Registrar" : "Programar"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {nutritionStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card
              key={index}
              className="aurora-card-glow hover:scale-105 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.title}
                    </p>
                    <div className="flex items-baseline gap-1 mt-2">
                      <p className="text-3xl font-bold text-gray-900">
                        {stat.value}
                      </p>
                      {stat.target && (
                        <p className="text-sm text-gray-500">{stat.target}</p>
                      )}
                    </div>
                    <p className="text-sm text-green-600 font-medium mt-1">
                      {stat.change} vs ayer
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-aurora-accent">
                    <Icon className="h-6 w-6 text-aurora-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="today" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="today">Hoy</TabsTrigger>
          <TabsTrigger value="plans">Planes</TabsTrigger>
          <TabsTrigger value="consultations">Consultas</TabsTrigger>
          <TabsTrigger value="analytics">Análisis</TabsTrigger>
        </TabsList>

        {/* Today Tab */}
        <TabsContent value="today" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="gym-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Utensils className="h-5 w-5 text-gym-primary" />
                    Comidas de Hoy
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {todayMeals.map((meal) => (
                    <div
                      key={meal.id}
                      className={`p-4 border rounded-lg transition-all ${
                        meal.completed
                          ? "bg-green-50 border-green-200"
                          : "hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              meal.completed ? "bg-green-500" : "bg-gray-300"
                            }`}
                          />
                          <h4 className="font-semibold text-gray-900">
                            {meal.name}
                          </h4>
                          <Badge
                            variant="outline"
                            className="text-xs bg-blue-50"
                          >
                            {meal.time}
                          </Badge>
                        </div>
                        <span className="text-sm font-medium text-gym-primary">
                          {meal.calories} kcal
                        </span>
                      </div>
                      <div className="text-sm text-gray-600 mb-3">
                        {meal.foods.join(" • ")}
                      </div>
                      {!meal.completed && (
                        <Button size="sm" variant="outline">
                          Marcar como completado
                        </Button>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              {/* Daily Progress */}
              <Card className="gym-card">
                <CardHeader>
                  <CardTitle>Progreso Diario</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gym-primary mb-2">
                      {consumedCalories}
                    </div>
                    <p className="text-sm text-gray-600">
                      de {totalCalories} kcal
                    </p>
                    <Progress
                      value={(consumedCalories / totalCalories) * 100}
                      className="mt-3"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                    <div className="text-center">
                      <p className="text-lg font-bold text-blue-600">125g</p>
                      <p className="text-xs text-gray-600">Proteína</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-green-600">2.1L</p>
                      <p className="text-xs text-gray-600">Agua</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Add */}
              <Card className="gym-card">
                <CardHeader>
                  <CardTitle>Agregar Rápido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2"
                  >
                    <Droplet className="h-4 w-4" />
                    +250ml Agua
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2"
                  >
                    <Apple className="h-4 w-4" />
                    Fruta
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start gap-2"
                  >
                    <ChefHat className="h-4 w-4" />
                    Proteína
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Plans Tab */}
        <TabsContent value="plans" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {mealPlans.map((plan) => (
              <Card key={plan.id} className="gym-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <Badge
                      variant={
                        plan.status === "active" ? "default" : "secondary"
                      }
                      className={
                        plan.status === "active"
                          ? "bg-green-100 text-green-800"
                          : ""
                      }
                    >
                      {plan.status === "active" ? "Activo" : "Completado"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">{plan.description}</p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Calorías:</span>{" "}
                      {plan.calories}
                    </div>
                    <div>
                      <span className="font-medium">Duración:</span>{" "}
                      {plan.duration}
                    </div>
                    <div>
                      <span className="font-medium">Comidas:</span> {plan.meals}{" "}
                      al día
                    </div>
                    <div>
                      <span className="font-medium">Nutricionista:</span>{" "}
                      {plan.coach}
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progreso</span>
                      <span>{plan.progress}%</span>
                    </div>
                    <Progress value={plan.progress} className="h-2" />
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      Ver Detalles
                    </Button>
                    {(isCoach || isAdmin) && (
                      <Button size="sm" className="gym-button-primary flex-1">
                        Editar
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Consultations Tab */}
        <TabsContent value="consultations" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-gym-primary" />
                {isCoach ? "Mis Consultas" : "Próximas Consultas"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {consultations.map((consultation) => (
                <div
                  key={consultation.id}
                  className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">
                      {consultation.type}
                    </h4>
                    <Badge variant="outline" className="bg-blue-50">
                      {consultation.status === "scheduled"
                        ? "Programada"
                        : "Completada"}
                    </Badge>
                  </div>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>
                      📅 {consultation.date} a las {consultation.time}
                    </p>
                    <p>
                      {consultation.client
                        ? `👤 Cliente: ${consultation.client}`
                        : `👨‍⚕️ Nutricionista: ${consultation.nutritionist}`}
                    </p>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" variant="outline">
                      Ver Detalles
                    </Button>
                    {isCoach && (
                      <Button size="sm" className="gym-button-primary">
                        Iniciar Consulta
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-gym-primary" />
                Análisis Nutricional
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gym-primary mb-2">
                    92%
                  </div>
                  <p className="text-sm text-gray-600">Adherencia al Plan</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    -2.5kg
                  </div>
                  <p className="text-sm text-gray-600">Peso Perdido</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    2,180
                  </div>
                  <p className="text-sm text-gray-600">Kcal Promedio</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Nutrition;
