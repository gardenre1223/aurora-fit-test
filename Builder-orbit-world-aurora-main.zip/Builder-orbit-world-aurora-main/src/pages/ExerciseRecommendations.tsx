import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Dumbbell,
  Search,
  Filter,
  Play,
  Clock,
  Target,
  Zap,
  User,
  Users,
  Award,
  Heart,
  TrendingUp,
  Plus,
  Star,
} from "lucide-react";
import {
  exerciseDatabase,
  workoutPlans,
  getExercisesByMuscleGroup,
  getWorkoutPlansByLevel,
  generateCustomWorkout,
  getMuscleGroupRecommendations,
  type Exercise,
  type WorkoutPlan,
  type MuscleGroup,
  type ExerciseLevel,
  type EquipmentType,
} from "@/lib/exercises";
import { authManager } from "@/lib/auth";

const ExerciseRecommendations = () => {
  const [selectedMuscleGroup, setSelectedMuscleGroup] = useState<
    MuscleGroup | "all"
  >("all");
  const [selectedLevel, setSelectedLevel] = useState<ExerciseLevel | "all">(
    "all",
  );
  const [selectedEquipment, setSelectedEquipment] = useState<
    EquipmentType | "all"
  >("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(
    null,
  );
  const [selectedPlan, setSelectedPlan] = useState<WorkoutPlan | null>(null);

  const user = authManager.getCurrentUser();

  // Muscle group data with icons and descriptions
  const muscleGroups = [
    {
      id: "pecho" as MuscleGroup,
      name: "Pecho",
      icon: "💪",
      description: "Pectorales y músculos del pecho",
      color: "from-red-500 to-pink-600",
    },
    {
      id: "espalda" as MuscleGroup,
      name: "Espalda",
      icon: "🏋️",
      description: "Dorsales, romboides y trapecio",
      color: "from-blue-500 to-cyan-600",
    },
    {
      id: "piernas" as MuscleGroup,
      name: "Piernas",
      icon: "🦵",
      description: "Cuádriceps, isquiotibiales y pantorrillas",
      color: "from-green-500 to-emerald-600",
    },
    {
      id: "hombros" as MuscleGroup,
      name: "Hombros",
      icon: "🏆",
      description: "Deltoides anterior, medio y posterior",
      color: "from-yellow-500 to-orange-600",
    },
    {
      id: "biceps" as MuscleGroup,
      name: "Bíceps",
      icon: "💪",
      description: "Músculos frontales del brazo",
      color: "from-purple-500 to-violet-600",
    },
    {
      id: "triceps" as MuscleGroup,
      name: "Tríceps",
      icon: "💥",
      description: "Músculos posteriores del brazo",
      color: "from-indigo-500 to-blue-600",
    },
    {
      id: "abdominales" as MuscleGroup,
      name: "Abdominales",
      icon: "⚡",
      description: "Core y músculos del abdomen",
      color: "from-teal-500 to-cyan-600",
    },
    {
      id: "gluteos" as MuscleGroup,
      name: "Glúteos",
      icon: "🍑",
      description: "Músculos de los glúteos",
      color: "from-pink-500 to-rose-600",
    },
    {
      id: "cardio" as MuscleGroup,
      name: "Cardio",
      icon: "❤️",
      description: "Ejercicios cardiovasculares",
      color: "from-red-500 to-orange-600",
    },
  ];

  // Filter exercises based on selections
  const filteredExercises = useMemo(() => {
    let filtered = exerciseDatabase;

    if (selectedMuscleGroup !== "all") {
      filtered = getExercisesByMuscleGroup(selectedMuscleGroup);
    }

    if (selectedLevel !== "all") {
      filtered = filtered.filter((ex) => ex.level === selectedLevel);
    }

    if (selectedEquipment !== "all") {
      filtered = filtered.filter((ex) =>
        ex.equipment.includes(selectedEquipment),
      );
    }

    if (searchTerm) {
      filtered = filtered.filter(
        (ex) =>
          ex.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          ex.description.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    return filtered;
  }, [selectedMuscleGroup, selectedLevel, selectedEquipment, searchTerm]);

  // Filter workout plans
  const filteredPlans = useMemo(() => {
    let filtered = workoutPlans;

    if (selectedLevel !== "all") {
      filtered = getWorkoutPlansByLevel(selectedLevel);
    }

    return filtered;
  }, [selectedLevel]);

  const getLevelColor = (level: ExerciseLevel) => {
    switch (level) {
      case "principiante":
        return "bg-green-100 text-green-800";
      case "intermedio":
        return "bg-yellow-100 text-yellow-800";
      case "avanzado":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getEquipmentIcon = (equipment: EquipmentType) => {
    switch (equipment) {
      case "mancuernas":
        return "🏋️";
      case "barra":
        return "💪";
      case "maquina":
        return "⚙️";
      case "peso_corporal":
        return "🤸";
      case "cable":
        return "🔗";
      case "kettlebell":
        return "⚡";
      case "banda_elastica":
        return "🎯";
      default:
        return "🏋️";
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold aurora-text-gradient flex items-center justify-center gap-3">
          <Dumbbell className="h-10 w-10 text-aurora-primary" />
          Recomendaciones de Ejercicios
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Descubre ejercicios personalizados para cada grupo muscular y crea tu
          rutina perfecta
        </p>
      </div>

      {/* Quick Muscle Group Selection */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {muscleGroups.map((group, index) => (
          <Card
            key={group.id}
            className={`cursor-pointer transition-all duration-300 hover:scale-105 aurora-card ${
              selectedMuscleGroup === group.id
                ? "ring-2 ring-aurora-primary bg-aurora-accent"
                : ""
            }`}
            onClick={() =>
              setSelectedMuscleGroup(
                selectedMuscleGroup === group.id ? "all" : group.id,
              )
            }
          >
            <CardContent className="p-4 text-center">
              <div
                className={`w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-r ${group.color} flex items-center justify-center text-2xl text-white shadow-lg`}
              >
                {group.icon}
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">{group.name}</h3>
              <p className="text-xs text-gray-600">{group.description}</p>
              <Badge
                variant="outline"
                className="mt-2 text-xs bg-aurora-accent text-aurora-primary"
              >
                {
                  exerciseDatabase.filter(
                    (ex) =>
                      ex.muscleGroup === group.id ||
                      ex.secondaryMuscles?.includes(group.id),
                  ).length
                }{" "}
                ejercicios
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="exercises" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="exercises">Explorar Ejercicios</TabsTrigger>
          <TabsTrigger value="plans">Planes Prediseñados</TabsTrigger>
          <TabsTrigger value="custom">Crear Rutina Custom</TabsTrigger>
        </TabsList>

        {/* Exercises Tab */}
        <TabsContent value="exercises" className="space-y-6">
          {/* Filters */}
          <Card className="aurora-card">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Buscar ejercicios..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select
                  value={selectedLevel}
                  onValueChange={(value) =>
                    setSelectedLevel(value as ExerciseLevel | "all")
                  }
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los niveles</SelectItem>
                    <SelectItem value="principiante">Principiante</SelectItem>
                    <SelectItem value="intermedio">Intermedio</SelectItem>
                    <SelectItem value="avanzado">Avanzado</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={selectedEquipment}
                  onValueChange={(value) =>
                    setSelectedEquipment(value as EquipmentType | "all")
                  }
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Equipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todo el equipo</SelectItem>
                    <SelectItem value="peso_corporal">Peso corporal</SelectItem>
                    <SelectItem value="mancuernas">Mancuernas</SelectItem>
                    <SelectItem value="barra">Barra</SelectItem>
                    <SelectItem value="maquina">Máquina</SelectItem>
                    <SelectItem value="cable">Cable</SelectItem>
                    <SelectItem value="kettlebell">Kettlebell</SelectItem>
                    <SelectItem value="banda_elastica">
                      Banda elástica
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Exercise Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredExercises.map((exercise) => (
              <Card
                key={exercise.id}
                className="aurora-card hover:scale-105 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedExercise(exercise)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{exercise.name}</CardTitle>
                    <Badge className={getLevelColor(exercise.level)}>
                      {exercise.level}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    {exercise.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    <Badge
                      variant="outline"
                      className="bg-aurora-accent text-aurora-primary"
                    >
                      {exercise.muscleGroup}
                    </Badge>
                    {exercise.secondaryMuscles?.map((muscle) => (
                      <Badge key={muscle} variant="outline" className="text-xs">
                        {muscle}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{exercise.rest || "1-2 min"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-orange-500" />
                      <span>{exercise.calories || 5} cal/min</span>
                    </div>
                  </div>

                  <div className="flex gap-1">
                    {exercise.equipment.map((eq) => (
                      <span key={eq} className="text-lg" title={eq}>
                        {getEquipmentIcon(eq)}
                      </span>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    className="w-full hover:bg-aurora-accent hover:text-aurora-primary transition-all"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Ver Detalles
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredExercises.length === 0 && (
            <Card className="aurora-card">
              <CardContent className="text-center py-12">
                <Dumbbell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  No se encontraron ejercicios
                </h3>
                <p className="text-gray-600">
                  Intenta ajustar los filtros de búsqueda
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Plans Tab */}
        <TabsContent value="plans" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredPlans.map((plan) => (
              <Card
                key={plan.id}
                className="aurora-card-glow hover:scale-105 transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedPlan(plan)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                    <Badge className={getLevelColor(plan.level)}>
                      {plan.level}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">{plan.description}</p>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{plan.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="h-4 w-4 text-gray-500" />
                      <span>{plan.frequency}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Zap className="h-4 w-4 text-orange-500" />
                      <span>{plan.caloriesBurn} cal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-blue-500" />
                      <span>{plan.estimatedTime} min</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {plan.muscleGroups.map((muscle) => (
                      <Badge
                        key={muscle}
                        variant="outline"
                        className="bg-aurora-accent text-aurora-primary"
                      >
                        {muscle}
                      </Badge>
                    ))}
                  </div>

                  <Button className="w-full aurora-button-primary">
                    <Star className="h-4 w-4 mr-2" />
                    Usar este Plan
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Custom Workout Creator */}
        <TabsContent value="custom" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-6 w-6 text-aurora-primary" />
                Crear Rutina Personalizada
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Nivel de experiencia
                  </label>
                  <Select defaultValue="intermedio">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="principiante">Principiante</SelectItem>
                      <SelectItem value="intermedio">Intermedio</SelectItem>
                      <SelectItem value="avanzado">Avanzado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Duración (minutos)
                  </label>
                  <Select defaultValue="60">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 minutos</SelectItem>
                      <SelectItem value="45">45 minutos</SelectItem>
                      <SelectItem value="60">60 minutos</SelectItem>
                      <SelectItem value="90">90 minutos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Objetivo principal
                  </label>
                  <Select defaultValue="fuerza">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fuerza">Ganar fuerza</SelectItem>
                      <SelectItem value="resistencia">
                        Resistencia muscular
                      </SelectItem>
                      <SelectItem value="cardio">Cardio intenso</SelectItem>
                      <SelectItem value="hipertrofia">Ganar músculo</SelectItem>
                      <SelectItem value="perdida">Perder peso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-3 block">
                  Grupos musculares a trabajar (selecciona varios)
                </label>
                <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                  {muscleGroups.slice(0, -1).map((group) => (
                    <Button
                      key={group.id}
                      variant="outline"
                      className="h-auto p-3 flex flex-col gap-2 hover:bg-aurora-accent hover:text-aurora-primary"
                    >
                      <span className="text-xl">{group.icon}</span>
                      <span className="text-xs">{group.name}</span>
                    </Button>
                  ))}
                </div>
              </div>

              <Button className="w-full aurora-button-primary h-12 text-lg">
                <Zap className="h-5 w-5 mr-2" />
                Generar Mi Rutina Personalizada
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Exercise Detail Modal */}
      {selectedExercise && (
        <Dialog
          open={!!selectedExercise}
          onOpenChange={() => setSelectedExercise(null)}
        >
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-3">
                <div className="p-2 aurora-gradient rounded-lg">
                  <Dumbbell className="h-6 w-6 text-white" />
                </div>
                {selectedExercise.name}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6">
              <div className="flex flex-wrap gap-2">
                <Badge className={getLevelColor(selectedExercise.level)}>
                  {selectedExercise.level}
                </Badge>
                <Badge
                  variant="outline"
                  className="bg-aurora-accent text-aurora-primary"
                >
                  {selectedExercise.muscleGroup}
                </Badge>
                {selectedExercise.equipment.map((eq) => (
                  <Badge key={eq} variant="outline">
                    {getEquipmentIcon(eq)} {eq}
                  </Badge>
                ))}
              </div>

              <div>
                <h4 className="font-semibold mb-2">Descripción</h4>
                <p className="text-gray-600">{selectedExercise.description}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Instrucciones</h4>
                <ol className="space-y-2">
                  {selectedExercise.instructions.map((instruction, index) => (
                    <li key={index} className="flex gap-3">
                      <span className="w-6 h-6 bg-aurora-primary text-white rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                        {index + 1}
                      </span>
                      <span className="text-gray-700">{instruction}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <h4 className="font-semibold mb-3">Consejos Importantes</h4>
                <ul className="space-y-2">
                  {selectedExercise.tips.map((tip, index) => (
                    <li key={index} className="flex gap-3">
                      <span className="w-2 h-2 bg-aurora-secondary rounded-full mt-2 flex-shrink-0"></span>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {selectedExercise.sets && (
                <div>
                  <h4 className="font-semibold mb-3">
                    Series y Repeticiones Recomendadas
                  </h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <p className="text-sm text-gray-600">Principiante</p>
                      <p className="font-bold text-green-600">
                        {selectedExercise.sets.beginner} series
                      </p>
                      <p className="text-sm">
                        {selectedExercise.reps?.beginner} reps
                      </p>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <p className="text-sm text-gray-600">Intermedio</p>
                      <p className="font-bold text-yellow-600">
                        {selectedExercise.sets.intermediate} series
                      </p>
                      <p className="text-sm">
                        {selectedExercise.reps?.intermediate} reps
                      </p>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <p className="text-sm text-gray-600">Avanzado</p>
                      <p className="font-bold text-red-600">
                        {selectedExercise.sets.advanced} series
                      </p>
                      <p className="text-sm">
                        {selectedExercise.reps?.advanced} reps
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <Button className="flex-1 aurora-button-primary">
                  <Plus className="h-4 w-4 mr-2" />
                  Agregar a Mi Rutina
                </Button>
                <Button variant="outline" className="flex-1">
                  <Heart className="h-4 w-4 mr-2" />
                  Marcar Favorito
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Plan Detail Modal */}
      {selectedPlan && (
        <Dialog
          open={!!selectedPlan}
          onOpenChange={() => setSelectedPlan(null)}
        >
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-2xl">
                {selectedPlan.name}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6">
              <div className="flex flex-wrap gap-2">
                <Badge className={getLevelColor(selectedPlan.level)}>
                  {selectedPlan.level}
                </Badge>
                <Badge variant="outline">{selectedPlan.duration}</Badge>
                <Badge variant="outline">{selectedPlan.frequency}</Badge>
                <Badge variant="outline">
                  {selectedPlan.estimatedTime} min
                </Badge>
                <Badge variant="outline">
                  {selectedPlan.caloriesBurn} calorías
                </Badge>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Objetivo</h4>
                <p className="text-gray-600">{selectedPlan.goal}</p>
              </div>

              <div>
                <h4 className="font-semibold mb-3">
                  Ejercicios ({selectedPlan.exercises.length})
                </h4>
                <div className="space-y-3">
                  {selectedPlan.exercises.map((planExercise, index) => {
                    const exercise = exerciseDatabase.find(
                      (ex) => ex.id === planExercise.exerciseId,
                    );
                    return (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div>
                          <h5 className="font-medium">{exercise?.name}</h5>
                          <p className="text-sm text-gray-600">
                            {exercise?.muscleGroup}
                          </p>
                          {planExercise.notes && (
                            <p className="text-xs text-aurora-primary">
                              {planExercise.notes}
                            </p>
                          )}
                        </div>
                        <div className="text-right text-sm">
                          <p className="font-medium">
                            {planExercise.sets} × {planExercise.reps}
                          </p>
                          <p className="text-gray-600">{planExercise.rest}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex gap-3">
                <Button className="flex-1 aurora-button-primary">
                  <Star className="h-4 w-4 mr-2" />
                  Adoptar Este Plan
                </Button>
                <Button variant="outline" className="flex-1">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Ver Progreso Esperado
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ExerciseRecommendations;
