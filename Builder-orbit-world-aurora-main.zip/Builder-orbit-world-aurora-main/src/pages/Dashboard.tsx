import { Outlet, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { DashboardNav } from "@/components/ui/dashboard-nav";
import { AIAssistantTrigger } from "@/components/ui/ai-assistant";
import { authManager } from "@/lib/auth";

const Dashboard = () => {
  const navigate = useNavigate();
  const user = authManager.getCurrentUser();
  const currentLocation = authManager.getCurrentLocation();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    if (!currentLocation) {
      navigate("/location-selection");
      return;
    }
  }, [user, currentLocation, navigate]);

  if (!user || !currentLocation) {
    return null;
  }

  return (
    <>
      <DashboardNav>
        <Outlet />
      </DashboardNav>
      <AIAssistantTrigger />
    </>
  );
};

export default Dashboard;
