import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  History as HistoryIcon,
  Calendar as CalendarIcon,
  Search,
  Filter,
  Download,
  Activity,
  Dumbbell,
  Apple,
  Users,
  Settings,
} from "lucide-react";
import { authManager } from "@/lib/auth";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const History = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const user = authManager.getCurrentUser();

  if (!user) return null;

  const isAdmin = user.role === "administrator";
  const isCoach = user.role === "coach";
  const isUser = user.role === "user";

  // Mock activity data based on user role
  const activities = [
    {
      id: 1,
      type: "training",
      title: isUser
        ? "Sesión de entrenamiento completada"
        : "Sesión programada para Carlos Ruiz",
      description: isUser
        ? "Entrenamiento de fuerza - 60 minutos"
        : "Entrenamiento personalizado de fuerza",
      timestamp: "2024-01-15 09:30",
      status: "completed",
      details: {
        duration: "60 min",
        coach: isUser ? "María González" : undefined,
        client: isCoach ? "Carlos Ruiz" : undefined,
      },
    },
    {
      id: 2,
      type: "nutrition",
      title: isUser
        ? "Plan nutricional actualizado"
        : "Plan nutricional creado para Ana Martínez",
      description: isUser
        ? "Nuevo plan de definición asignado"
        : "Plan personalizado de pérdida de peso",
      timestamp: "2024-01-14 16:15",
      status: "updated",
      details: {
        calories: "2,200 kcal",
        nutritionist: isUser ? "Dr. Ana Ruiz" : undefined,
        client: isCoach ? "Ana Martínez" : undefined,
      },
    },
    {
      id: 3,
      type: "profile",
      title: "Perfil actualizado",
      description: "Información personal modificada",
      timestamp: "2024-01-13 11:20",
      status: "updated",
      details: {
        fields: ["Teléfono", "Dirección"],
      },
    },
    {
      id: 4,
      type: "payment",
      title: isAdmin
        ? "Pago procesado - Roberto Silva"
        : isUser
          ? "Pago de membresía procesado"
          : "Pago registrado para cliente",
      description: isAdmin
        ? "Plan mensual renovado"
        : "Membresía mensual renovada",
      timestamp: "2024-01-12 14:45",
      status: "completed",
      details: {
        amount: "$1,200 MXN",
        plan: "Membresía Premium",
      },
    },
    {
      id: 5,
      type: "user_management",
      title: "Nuevo miembro registrado",
      description: "Sofia López se unió al gimnasio",
      timestamp: "2024-01-11 10:30",
      status: "created",
      details: {
        plan: "Plan Básico",
        referral: "Recomendación",
      },
      visible: isAdmin || isCoach,
    },
    {
      id: 6,
      type: "system",
      title: "Configuración actualizada",
      description: "Horarios de gimnasio modificados",
      timestamp: "2024-01-10 08:00",
      status: "updated",
      details: {
        setting: "Horarios de operación",
      },
      visible: isAdmin,
    },
  ].filter((activity) => activity.visible !== false);

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "training":
        return <Dumbbell className="h-4 w-4" />;
      case "nutrition":
        return <Apple className="h-4 w-4" />;
      case "profile":
        return <Users className="h-4 w-4" />;
      case "payment":
        return <Activity className="h-4 w-4" />;
      case "user_management":
        return <Users className="h-4 w-4" />;
      case "system":
        return <Settings className="h-4 w-4" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "updated":
        return "bg-blue-100 text-blue-800";
      case "created":
        return "bg-purple-100 text-purple-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "Completado";
      case "updated":
        return "Actualizado";
      case "created":
        return "Creado";
      case "cancelled":
        return "Cancelado";
      default:
        return status;
    }
  };

  const filteredActivities = activities.filter((activity) => {
    const matchesSearch = activity.title
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === "all" || activity.type === filterType;
    return matchesSearch && matchesFilter;
  });

  const stats = [
    {
      title: "Total de Actividades",
      value: activities.length.toString(),
      change: "+12%",
      icon: HistoryIcon,
    },
    {
      title: isUser ? "Sesiones Este Mes" : "Acciones Este Mes",
      value: "28",
      change: "+8%",
      icon: Activity,
    },
    {
      title: "Última Actividad",
      value: "Hoy",
      change: "09:30",
      icon: CalendarIcon,
    },
    {
      title: "Más Frecuente",
      value: isUser ? "Entrenamiento" : "Gestión",
      change: "45%",
      icon: Dumbbell,
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <HistoryIcon className="h-8 w-8 text-gym-primary" />
            Historial de Actividades
          </h1>
          <p className="text-gray-600 mt-1">
            {isAdmin
              ? "Registro completo de todas las actividades del sistema"
              : isCoach
                ? "Historial de tus actividades y gestión de clientes"
                : "Tu historial de actividades en el gimnasio"}
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Exportar
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card
              key={index}
              className="gym-card hover:shadow-lg transition-all"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">
                      {stat.value}
                    </p>
                    <p className="text-sm text-green-600 font-medium mt-1">
                      {stat.change}
                    </p>
                  </div>
                  <div className="p-3 rounded-full bg-gym-accent">
                    <Icon className="h-6 w-6 text-gym-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Filters and Search */}
      <Card className="gym-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gym-primary" />
            Filtros
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar actividades..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Tipo de actividad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las actividades</SelectItem>
                <SelectItem value="training">Entrenamientos</SelectItem>
                <SelectItem value="nutrition">Nutrición</SelectItem>
                <SelectItem value="profile">Perfil</SelectItem>
                {(isAdmin || isCoach) && (
                  <SelectItem value="payment">Pagos</SelectItem>
                )}
                {(isAdmin || isCoach) && (
                  <SelectItem value="user_management">
                    Gestión de usuarios
                  </SelectItem>
                )}
                {isAdmin && <SelectItem value="system">Sistema</SelectItem>}
              </SelectContent>
            </Select>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  {selectedDate
                    ? format(selectedDate, "PPP", { locale: es })
                    : "Seleccionar fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </CardContent>
      </Card>

      {/* Activity Timeline */}
      <Card className="gym-card">
        <CardHeader>
          <CardTitle>Cronología de Actividades</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredActivities.length > 0 ? (
              filteredActivities.map((activity, index) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-shrink-0 p-2 bg-gym-accent rounded-full">
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">
                        {activity.title}
                      </h4>
                      <Badge
                        variant="secondary"
                        className={getStatusColor(activity.status)}
                      >
                        {getStatusLabel(activity.status)}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">
                      {activity.description}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span>📅 {activity.timestamp}</span>
                      {activity.details.duration && (
                        <span>⏱️ {activity.details.duration}</span>
                      )}
                      {activity.details.coach && (
                        <span>👨‍💼 {activity.details.coach}</span>
                      )}
                      {activity.details.client && (
                        <span>👤 {activity.details.client}</span>
                      )}
                      {activity.details.amount && (
                        <span>💰 {activity.details.amount}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <HistoryIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  No se encontraron actividades
                </h3>
                <p className="text-gray-600">
                  Intenta ajustar los filtros de búsqueda
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default History;
