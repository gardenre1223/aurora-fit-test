import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Building2,
  Plus,
  MapPin,
  Clock,
  Users,
  TrendingUp,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  Phone,
  Mail,
  Activity,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";
import { authManager } from "@/lib/auth";

interface Location {
  id: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  email: string;
  manager: string;
  isActive: boolean;
  capacity: number;
  currentMembers: number;
  openingTime: string;
  closingTime: string;
  amenities: string[];
  monthlyRevenue: number;
  createdDate: string;
}

const LocationManagement = () => {
  const [isCreateLocationOpen, setIsCreateLocationOpen] = useState(false);
  const [isEditLocationOpen, setIsEditLocationOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(
    null,
  );
  const [searchTerm, setSearchTerm] = useState("");

  const user = authManager.getCurrentUser();

  if (!user || user.role !== "administrator") {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Acceso Restringido</h2>
          <p className="text-gray-600">
            Solo los administradores pueden gestionar las sedes.
          </p>
        </div>
      </div>
    );
  }

  // Mock locations data
  const [locations, setLocations] = useState<Location[]>([
    {
      id: "1",
      name: "AuroraFit Centro",
      address: "Av. Reforma 123",
      city: "Ciudad de México",
      phone: "+52 555 100 1001",
      email: "centro@aurorafit.com",
      manager: "Carlos Mendoza",
      isActive: true,
      capacity: 150,
      currentMembers: 89,
      openingTime: "05:00",
      closingTime: "23:00",
      amenities: [
        "Pesas",
        "Cardio",
        "Clases grupales",
        "Spa",
        "Estacionamiento",
      ],
      monthlyRevenue: 285000,
      createdDate: "2023-01-15",
    },
    {
      id: "2",
      name: "AuroraFit Polanco",
      address: "Av. Masaryk 456",
      city: "Ciudad de México",
      phone: "+52 555 100 1002",
      email: "polanco@aurorafit.com",
      manager: "Ana González",
      isActive: true,
      capacity: 200,
      currentMembers: 156,
      openingTime: "05:30",
      closingTime: "22:30",
      amenities: [
        "Pesas",
        "Cardio",
        "Clases grupales",
        "Piscina",
        "Sauna",
        "Estacionamiento",
      ],
      monthlyRevenue: 425000,
      createdDate: "2023-03-22",
    },
    {
      id: "3",
      name: "AuroraFit Santa Fe",
      address: "Av. Santa Fe 789",
      city: "Ciudad de México",
      phone: "+52 555 100 1003",
      email: "santafe@aurorafit.com",
      manager: "Roberto Silva",
      isActive: true,
      capacity: 180,
      currentMembers: 134,
      openingTime: "06:00",
      closingTime: "22:00",
      amenities: ["Pesas", "Cardio", "Clases grupales", "Nutrición"],
      monthlyRevenue: 365000,
      createdDate: "2023-06-10",
    },
    {
      id: "4",
      name: "AuroraFit Condesa",
      address: "Av. Insurgentes 321",
      city: "Ciudad de México",
      phone: "+52 555 100 1004",
      email: "condesa@aurorafit.com",
      manager: "María López",
      isActive: false,
      capacity: 120,
      currentMembers: 0,
      openingTime: "07:00",
      closingTime: "21:00",
      amenities: ["Pesas", "Cardio"],
      monthlyRevenue: 0,
      createdDate: "2023-08-15",
    },
    {
      id: "5",
      name: "AuroraFit Roma Norte",
      address: "Calle Orizaba 567",
      city: "Ciudad de México",
      phone: "+52 555 100 1005",
      email: "roma@aurorafit.com",
      manager: "Luis García",
      isActive: true,
      capacity: 100,
      currentMembers: 67,
      openingTime: "06:00",
      closingTime: "22:00",
      amenities: ["Pesas", "Cardio", "Clases grupales", "Yoga"],
      monthlyRevenue: 195000,
      createdDate: "2023-11-05",
    },
  ]);

  const filteredLocations = locations.filter(
    (location) =>
      location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.address.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const totalLocations = locations.length;
  const activeLocations = locations.filter((loc) => loc.isActive).length;
  const totalCapacity = locations.reduce((sum, loc) => sum + loc.capacity, 0);
  const totalMembers = locations.reduce(
    (sum, loc) => sum + loc.currentMembers,
    0,
  );
  const totalRevenue = locations.reduce(
    (sum, loc) => sum + loc.monthlyRevenue,
    0,
  );

  const handleEditLocation = (location: Location) => {
    setSelectedLocation(location);
    setIsEditLocationOpen(true);
  };

  const handleToggleLocationStatus = (locationId: string) => {
    setLocations((prev) =>
      prev.map((loc) =>
        loc.id === locationId ? { ...loc, isActive: !loc.isActive } : loc,
      ),
    );
  };

  const getOccupancyColor = (current: number, capacity: number) => {
    const percentage = (current / capacity) * 100;
    if (percentage < 50) return "text-green-600";
    if (percentage < 80) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <Building2 className="h-8 w-8 text-aurora-primary" />
            Gestión de Sedes
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            Administra todas las ubicaciones de AuroraFit
          </p>
        </div>
        <Dialog
          open={isCreateLocationOpen}
          onOpenChange={setIsCreateLocationOpen}
        >
          <DialogTrigger asChild>
            <Button className="aurora-button-primary gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
              <Plus className="h-4 w-4" />
              Nueva Sede
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Crear Nueva Sede</DialogTitle>
            </DialogHeader>
            <LocationForm
              onClose={() => setIsCreateLocationOpen(false)}
              onSave={(locationData) => {
                // Add new location logic here
                setIsCreateLocationOpen(false);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Sedes</p>
                <p className="text-2xl font-bold">{totalLocations}</p>
              </div>
              <Building2 className="h-8 w-8 text-aurora-primary" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Sedes Activas</p>
                <p className="text-2xl font-bold text-green-600">
                  {activeLocations}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Capacidad Total</p>
                <p className="text-2xl font-bold text-blue-600">
                  {totalCapacity}
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Miembros Activos</p>
                <p className="text-2xl font-bold text-aurora-primary">
                  {totalMembers}
                </p>
              </div>
              <Activity className="h-8 w-8 text-aurora-primary" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ingresos Totales</p>
                <p className="text-2xl font-bold text-aurora-secondary">
                  ${(totalRevenue / 1000).toFixed(0)}K
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-aurora-secondary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="aurora-card">
        <CardContent className="p-4">
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar sedes por nombre, dirección o ciudad..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Locations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredLocations.map((location) => (
          <Card
            key={location.id}
            className={`aurora-card transition-all duration-300 hover:scale-[1.02] ${
              !location.isActive ? "opacity-75" : ""
            }`}
          >
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-lg ${location.isActive ? "bg-green-100" : "bg-gray-100"}`}
                  >
                    <Building2
                      className={`h-6 w-6 ${location.isActive ? "text-green-600" : "text-gray-400"}`}
                    />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{location.name}</CardTitle>
                    <p className="text-sm text-gray-600">{location.city}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    className={
                      location.isActive
                        ? "bg-green-100 text-green-800"
                        : "bg-gray-100 text-gray-800"
                    }
                  >
                    {location.isActive ? "Activa" : "Inactiva"}
                  </Badge>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                      <DropdownMenuItem
                        onClick={() => handleEditLocation(location)}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" />
                        Ver detalles
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => handleToggleLocationStatus(location.id)}
                      >
                        {location.isActive ? (
                          <>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Desactivar
                          </>
                        ) : (
                          <>
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Activar
                          </>
                        )}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-500" />
                  <span className="truncate">{location.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span>{location.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span className="truncate">{location.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-gray-500" />
                  <span>Gerente: {location.manager}</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Ocupación</span>
                  <span
                    className={getOccupancyColor(
                      location.currentMembers,
                      location.capacity,
                    )}
                  >
                    {location.currentMembers}/{location.capacity} miembros
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-aurora-primary h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min((location.currentMembers / location.capacity) * 100, 100)}%`,
                    }}
                  ></div>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-500" />
                  <span>
                    {location.openingTime} - {location.closingTime}
                  </span>
                </div>
                <div className="font-semibold text-aurora-primary">
                  ${(location.monthlyRevenue / 1000).toFixed(0)}K/mes
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">Servicios:</p>
                <div className="flex flex-wrap gap-1">
                  {location.amenities.slice(0, 3).map((amenity, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {amenity}
                    </Badge>
                  ))}
                  {location.amenities.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{location.amenities.length - 3} más
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Location Modal */}
      <Dialog open={isEditLocationOpen} onOpenChange={setIsEditLocationOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Editar Sede - {selectedLocation?.name}</DialogTitle>
          </DialogHeader>
          {selectedLocation && (
            <LocationForm
              location={selectedLocation}
              onClose={() => setIsEditLocationOpen(false)}
              onSave={(locationData) => {
                // Update location logic here
                setIsEditLocationOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Location Form Component
interface LocationFormProps {
  location?: Location;
  onClose: () => void;
  onSave: (locationData: Partial<Location>) => void;
}

const LocationForm = ({ location, onClose, onSave }: LocationFormProps) => {
  const [formData, setFormData] = useState({
    name: location?.name || "",
    address: location?.address || "",
    city: location?.city || "",
    phone: location?.phone || "",
    email: location?.email || "",
    manager: location?.manager || "",
    capacity: location?.capacity || 100,
    openingTime: location?.openingTime || "06:00",
    closingTime: location?.closingTime || "22:00",
    isActive: location?.isActive ?? true,
    amenities: location?.amenities?.join(", ") || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      amenities: formData.amenities
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Nombre de la Sede</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, name: e.target.value }))
            }
            placeholder="Ej. AuroraFit Centro"
            required
          />
        </div>
        <div>
          <Label htmlFor="city">Ciudad</Label>
          <Input
            id="city"
            value={formData.city}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, city: e.target.value }))
            }
            placeholder="Ciudad de México"
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="address">Dirección</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, address: e.target.value }))
          }
          placeholder="Av. Reforma 123"
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="phone">Teléfono</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, phone: e.target.value }))
            }
            placeholder="+52 555 100 1000"
            required
          />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, email: e.target.value }))
            }
            placeholder="sede@aurorafit.com"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="manager">Gerente</Label>
          <Input
            id="manager"
            value={formData.manager}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, manager: e.target.value }))
            }
            placeholder="Nombre del gerente"
            required
          />
        </div>
        <div>
          <Label htmlFor="openingTime">Hora de Apertura</Label>
          <Input
            id="openingTime"
            type="time"
            value={formData.openingTime}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, openingTime: e.target.value }))
            }
            required
          />
        </div>
        <div>
          <Label htmlFor="closingTime">Hora de Cierre</Label>
          <Input
            id="closingTime"
            type="time"
            value={formData.closingTime}
            onChange={(e) =>
              setFormData((prev) => ({ ...prev, closingTime: e.target.value }))
            }
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="capacity">Capacidad Máxima</Label>
        <Input
          id="capacity"
          type="number"
          value={formData.capacity}
          onChange={(e) =>
            setFormData((prev) => ({
              ...prev,
              capacity: parseInt(e.target.value),
            }))
          }
          min="1"
          required
        />
      </div>

      <div>
        <Label htmlFor="amenities">Servicios (separados por comas)</Label>
        <Textarea
          id="amenities"
          value={formData.amenities}
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, amenities: e.target.value }))
          }
          placeholder="Pesas, Cardio, Clases grupales, Spa, Estacionamiento"
          rows={3}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) =>
            setFormData((prev) => ({ ...prev, isActive: checked }))
          }
        />
        <Label htmlFor="isActive">Sede activa</Label>
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          className="flex-1"
        >
          Cancelar
        </Button>
        <Button type="submit" className="flex-1 aurora-button-primary">
          {location ? "Actualizar" : "Crear"} Sede
        </Button>
      </div>
    </form>
  );
};

export default LocationManagement;
