import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Calendar } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dumbbell,
  Calendar as CalendarIcon,
  Clock,
  Target,
  TrendingUp,
  Plus,
  Play,
  CheckCircle,
  BarChart3,
  MapPin,
  Lightbulb,
} from "lucide-react";
import { authManager, getUserPermissions } from "@/lib/auth";

const Training = () => {
  const navigate = useNavigate();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(
    new Date(),
  );
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const user = authManager.getCurrentUser();
  const permissions = user ? getUserPermissions(user.role) : null;

  if (!user) return null;

  const isAdmin = user.role === "administrator";
  const isCoach = user.role === "coach";
  const isUser = user.role === "user";

  // Mock data for training sessions
  const upcomingSessions = [
    {
      id: 1,
      title: "Entrenamiento de Fuerza",
      coach: "María González",
      client: isCoach ? "Carlos Ruiz" : undefined,
      date: "2024-01-15",
      time: "09:00",
      duration: 60,
      type: "personal",
      status: "scheduled",
    },
    {
      id: 2,
      title: "Cardio Intensivo",
      coach: "Roberto Silva",
      client: isCoach ? "Ana Martínez" : undefined,
      date: "2024-01-15",
      time: "16:00",
      duration: 45,
      type: "group",
      status: "scheduled",
    },
    {
      id: 3,
      title: "Functional Training",
      coach: "Luis García",
      client: isCoach ? "Sofia López" : undefined,
      date: "2024-01-16",
      time: "11:00",
      duration: 50,
      type: "functional",
      status: "scheduled",
    },
  ];

  const completedSessions = [
    {
      id: 4,
      title: "Entrenamiento de Piernas",
      coach: "María González",
      date: "2024-01-14",
      time: "09:00",
      duration: 60,
      type: "personal",
      status: "completed",
      rating: 5,
    },
    {
      id: 5,
      title: "HIIT Session",
      coach: "Roberto Silva",
      date: "2024-01-12",
      time: "18:00",
      duration: 30,
      type: "group",
      status: "completed",
      rating: 4,
    },
  ];

  const workoutPlans = [
    {
      id: 1,
      name: "Plan de Fuerza - Nivel Intermedio",
      description: "Enfoque en desarrollo muscular y aumento de fuerza",
      duration: "8 semanas",
      sessionsPerWeek: 4,
      progress: 65,
      exercises: 24,
      coach: "María González",
      status: "active",
    },
    {
      id: 2,
      name: "Plan Cardio para Resistencia",
      description: "Mejora tu capacidad cardiovascular",
      duration: "6 semanas",
      sessionsPerWeek: 3,
      progress: 40,
      exercises: 15,
      coach: "Roberto Silva",
      status: "active",
    },
  ];

  const stats = [
    {
      title: isCoach ? "Sesiones Programadas" : "Sesiones Este Mes",
      value: isCoach ? "24" : "12",
      change: "+8%",
      icon: CalendarIcon,
    },
    {
      title: isCoach ? "Clientes Activos" : "Tiempo Total",
      value: isCoach ? "18" : "28h",
      change: "+12%",
      icon: isCoach ? Users : Clock,
    },
    {
      title: "Progreso Promedio",
      value: "78%",
      change: "+5%",
      icon: TrendingUp,
    },
    {
      title: isCoach ? "Planes Asignados" : "Objetivos Cumplidos",
      value: isCoach ? "15" : "5",
      change: "+2",
      icon: Target,
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <Dumbbell className="h-8 w-8 text-aurora-primary" />
            Entrenamientos
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            {isAdmin
              ? "Gestiona todas las sesiones de entrenamiento del sistema"
              : isCoach
                ? "Programa y monitorea las sesiones de tus clientes"
                : "Tus entrenamientos y planes personalizados"}
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="aurora-button-primary gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
              <Plus className="h-4 w-4" />
              {isCoach ? "Nueva Sesión" : "Agendar Sesión"}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {isCoach ? "Crear Nueva Sesión" : "Agendar Sesión"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Tipo de Sesión</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal</SelectItem>
                    <SelectItem value="group">Grupal</SelectItem>
                    <SelectItem value="functional">Funcional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {isCoach && (
                <div>
                  <label className="text-sm font-medium">Cliente</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="carlos">Carlos Ruiz</SelectItem>
                      <SelectItem value="ana">Ana Martínez</SelectItem>
                      <SelectItem value="sofia">Sofia López</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Fecha</label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-md border"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Hora</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Hora" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="09:00">09:00</SelectItem>
                      <SelectItem value="10:00">10:00</SelectItem>
                      <SelectItem value="11:00">11:00</SelectItem>
                      <SelectItem value="16:00">16:00</SelectItem>
                      <SelectItem value="17:00">17:00</SelectItem>
                      <SelectItem value="18:00">18:00</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                className="w-full aurora-button-primary"
                onClick={() => setIsCreateDialogOpen(false)}
              >
                {isCoach ? "Crear Sesión" : "Agendar"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Exercise Recommendations Banner */}
      <Card className="aurora-card-glow bg-gradient-to-r from-aurora-accent via-white to-purple-50 border-aurora-primary/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 aurora-gradient rounded-xl">
                <Lightbulb className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  ¿Necesitas inspiración para tu entrenamiento?
                </h3>
                <p className="text-gray-600">
                  Explora +1000 ejercicios organizados por grupo muscular y crea
                  rutinas personalizadas
                </p>
              </div>
            </div>
            <Button
              className="aurora-button-secondary gap-2 shadow-lg"
              onClick={() => navigate("/dashboard/exercises")}
            >
              <Lightbulb className="h-4 w-4" />
              Ver Recomendaciones
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card
              key={index}
              className="aurora-card-glow hover:scale-105 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold text-gray-900 mt-2">
                      {stat.value}
                    </p>
                    <p className="text-sm text-green-600 font-medium mt-1">
                      {stat.change} vs último mes
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-aurora-accent">
                    <Icon className="h-6 w-6 text-aurora-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="sessions" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sessions">Sesiones</TabsTrigger>
          <TabsTrigger value="plans">Planes</TabsTrigger>
          <TabsTrigger value="progress">Progreso</TabsTrigger>
          <TabsTrigger value="calendar">Calendario</TabsTrigger>
        </TabsList>

        {/* Sessions Tab */}
        <TabsContent value="sessions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upcoming Sessions */}
            <Card className="aurora-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5 text-aurora-primary" />
                  Próximas Sesiones
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-4 border rounded-xl hover:bg-aurora-accent/30 transition-all duration-300 hover:border-aurora-primary/50"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">
                        {session.title}
                      </h4>
                      <Badge
                        variant="secondary"
                        className="bg-blue-100 text-blue-800"
                      >
                        {session.type}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>
                        📅 {session.date} a las {session.time}
                      </p>
                      <p>⏱️ {session.duration} minutos</p>
                      <p>
                        👨‍💼{" "}
                        {session.client
                          ? `Cliente: ${session.client}`
                          : `Coach: ${session.coach}`}
                      </p>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="hover:bg-aurora-accent hover:text-aurora-primary transition-all duration-300"
                      >
                        Ver Detalles
                      </Button>
                      {isCoach && (
                        <Button size="sm" className="aurora-button-primary">
                          Iniciar Sesión
                        </Button>
                      )}
                      {isUser && (
                        <Button size="sm" className="aurora-button-secondary">
                          Unirse
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Completed Sessions */}
            <Card className="gym-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  Sesiones Completadas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {completedSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-4 border rounded-lg bg-green-50 border-green-200"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">
                        {session.title}
                      </h4>
                      <div className="flex">
                        {[...Array(session.rating)].map((_, i) => (
                          <span key={i} className="text-yellow-400">
                            ⭐
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>
                        📅 {session.date} a las {session.time}
                      </p>
                      <p>⏱️ {session.duration} minutos</p>
                      <p>👨‍💼 Coach: {session.coach}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Plans Tab */}
        <TabsContent value="plans" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {workoutPlans.map((plan) => (
              <Card key={plan.id} className="gym-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <Badge
                      variant={
                        plan.status === "active" ? "default" : "secondary"
                      }
                      className={
                        plan.status === "active"
                          ? "bg-green-100 text-green-800"
                          : ""
                      }
                    >
                      {plan.status === "active" ? "Activo" : "Completado"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">{plan.description}</p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Duración:</span>{" "}
                      {plan.duration}
                    </div>
                    <div>
                      <span className="font-medium">Sesiones/semana:</span>{" "}
                      {plan.sessionsPerWeek}
                    </div>
                    <div>
                      <span className="font-medium">Ejercicios:</span>{" "}
                      {plan.exercises}
                    </div>
                    <div>
                      <span className="font-medium">Coach:</span> {plan.coach}
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progreso</span>
                      <span>{plan.progress}%</span>
                    </div>
                    <Progress value={plan.progress} className="h-2" />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1 hover:bg-aurora-accent hover:text-aurora-primary transition-all duration-300"
                    >
                      Ver Plan Completo
                    </Button>
                    {(isCoach || isAdmin) && (
                      <Button
                        size="sm"
                        className="aurora-button-primary flex-1"
                      >
                        Editar Plan
                      </Button>
                    )}
                    {isUser && (
                      <Button
                        size="sm"
                        className="aurora-button-secondary flex-1"
                      >
                        Iniciar Rutina
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {(isCoach || isAdmin) && (
            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Crear Nuevo Plan</CardTitle>
                <p className="text-sm text-gray-600">
                  Diseña rutinas personalizadas para tus clientes
                </p>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="aurora-button-primary gap-2 w-full">
                  <Plus className="h-4 w-4" />
                  Nuevo Plan de Entrenamiento
                </Button>
                <Button className="aurora-button-secondary gap-2 w-full">
                  <Target className="h-4 w-4" />
                  Usar Plantilla
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Progress Tab */}
        <TabsContent value="progress" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-gym-primary" />
                Análisis de Progreso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gym-primary mb-2">
                    85%
                  </div>
                  <p className="text-sm text-gray-600">Adherencia al Plan</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    +12kg
                  </div>
                  <p className="text-sm text-gray-600">Fuerza Ganada</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    24h
                  </div>
                  <p className="text-sm text-gray-600">Tiempo Total</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Calendar Tab */}
        <TabsContent value="calendar" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle>Calendario de Entrenamientos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Training;
