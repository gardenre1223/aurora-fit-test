import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Settings as SettingsIcon,
  User,
  Bell,
  Shield,
  Palette,
  Clock,
  Globe,
  Save,
  Building2,
  Users,
} from "lucide-react";
import { authManager, getUserPermissions } from "@/lib/auth";

const Settings = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    training: true,
    nutrition: true,
    payments: true,
  });
  const user = authManager.getCurrentUser();
  const permissions = user ? getUserPermissions(user.role) : null;

  if (!user) return null;

  const isAdmin = user.role === "administrator";
  const isCoach = user.role === "coach";
  const isUser = user.role === "user";

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <SettingsIcon className="h-8 w-8 text-gym-primary" />
            Configuración
          </h1>
          <p className="text-gray-600 mt-1">
            {isAdmin
              ? "Configuración del sistema y gestión general"
              : "Personaliza tu experiencia en la aplicación"}
          </p>
        </div>
        <Button className="gym-button-primary gap-2">
          <Save className="h-4 w-4" />
          Guardar Cambios
        </Button>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="notifications">Notificaciones</TabsTrigger>
          <TabsTrigger value="appearance">Apariencia</TabsTrigger>
          {isAdmin && <TabsTrigger value="system">Sistema</TabsTrigger>}
          {!isAdmin && <TabsTrigger value="privacy">Privacidad</TabsTrigger>}
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-gym-primary" />
                Configuración de Perfil
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">Nombre</Label>
                  <Input
                    id="firstName"
                    value={user.name.split(" ")[0]}
                    placeholder="Tu nombre"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Apellidos</Label>
                  <Input
                    id="lastName"
                    value={user.name.split(" ").slice(1).join(" ")}
                    placeholder="Tus apellidos"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Correo Electrónico</Label>
                  <Input
                    id="email"
                    type="email"
                    value={user.email}
                    placeholder="tu@email.com"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value="+52 555 123 4567"
                    placeholder="+52 555 123 4567"
                  />
                </div>
              </div>

              <Separator />

              <div>
                <Label htmlFor="timezone">Zona Horaria</Label>
                <Select defaultValue="america/mexico_city">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="america/mexico_city">
                      Ciudad de México (GMT-6)
                    </SelectItem>
                    <SelectItem value="america/cancun">
                      Cancún (GMT-5)
                    </SelectItem>
                    <SelectItem value="america/tijuana">
                      Tijuana (GMT-8)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="language">Idioma</Label>
                <Select defaultValue="es">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="es">Español</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {isUser && (
            <Card className="gym-card">
              <CardHeader>
                <CardTitle>Preferencias de Entrenamiento</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="fitness-goal">Objetivo Principal</Label>
                  <Select defaultValue="weight-loss">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight-loss">
                        Pérdida de peso
                      </SelectItem>
                      <SelectItem value="muscle-gain">Ganar músculo</SelectItem>
                      <SelectItem value="endurance">Resistencia</SelectItem>
                      <SelectItem value="general">Estado general</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="workout-frequency">
                    Frecuencia de Entrenamiento
                  </Label>
                  <Select defaultValue="4">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 veces por semana</SelectItem>
                      <SelectItem value="3">3 veces por semana</SelectItem>
                      <SelectItem value="4">4 veces por semana</SelectItem>
                      <SelectItem value="5">5 veces por semana</SelectItem>
                      <SelectItem value="6">6 veces por semana</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="preferred-time">Horario Preferido</Label>
                  <Select defaultValue="morning">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">
                        Mañana (6:00 - 12:00)
                      </SelectItem>
                      <SelectItem value="afternoon">
                        Tarde (12:00 - 18:00)
                      </SelectItem>
                      <SelectItem value="evening">
                        Noche (18:00 - 22:00)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-gym-primary" />
                Configuración de Notificaciones
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-4">Métodos de Notificación</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="email-notifications">
                        Notificaciones por Email
                      </Label>
                      <p className="text-sm text-gray-600">
                        Recibe notificaciones en tu correo electrónico
                      </p>
                    </div>
                    <Switch
                      id="email-notifications"
                      checked={notifications.email}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, email: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="push-notifications">
                        Notificaciones Push
                      </Label>
                      <p className="text-sm text-gray-600">
                        Notificaciones en tiempo real en tu dispositivo
                      </p>
                    </div>
                    <Switch
                      id="push-notifications"
                      checked={notifications.push}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, push: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="sms-notifications">SMS</Label>
                      <p className="text-sm text-gray-600">
                        Notificaciones por mensaje de texto
                      </p>
                    </div>
                    <Switch
                      id="sms-notifications"
                      checked={notifications.sms}
                      onCheckedChange={(checked) =>
                        setNotifications({ ...notifications, sms: checked })
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">Tipos de Notificación</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="training-notifications">
                        Entrenamientos
                      </Label>
                      <p className="text-sm text-gray-600">
                        Recordatorios de sesiones y cambios en rutinas
                      </p>
                    </div>
                    <Switch
                      id="training-notifications"
                      checked={notifications.training}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          training: checked,
                        })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="nutrition-notifications">Nutrición</Label>
                      <p className="text-sm text-gray-600">
                        Recordatorios de comidas y planes nutricionales
                      </p>
                    </div>
                    <Switch
                      id="nutrition-notifications"
                      checked={notifications.nutrition}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          nutrition: checked,
                        })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="payment-notifications">Pagos</Label>
                      <p className="text-sm text-gray-600">
                        Recordatorios de pagos y confirmaciones
                      </p>
                    </div>
                    <Switch
                      id="payment-notifications"
                      checked={notifications.payments}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          payments: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance */}
        <TabsContent value="appearance" className="space-y-6">
          <Card className="gym-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-gym-primary" />
                Configuración de Apariencia
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode">Modo Oscuro</Label>
                  <p className="text-sm text-gray-600">
                    Activa el tema oscuro para reducir la fatiga visual
                  </p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={isDarkMode}
                  onCheckedChange={setIsDarkMode}
                />
              </div>

              <Separator />

              <div>
                <Label htmlFor="theme">Tema de Colores</Label>
                <Select defaultValue="blue">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blue">Azul Profesional</SelectItem>
                    <SelectItem value="green">Verde Energía</SelectItem>
                    <SelectItem value="purple">Púrpura Premium</SelectItem>
                    <SelectItem value="orange">Naranja Dinámico</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="font-size">Tamaño de Fuente</Label>
                <Select defaultValue="medium">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Pequeño</SelectItem>
                    <SelectItem value="medium">Mediano</SelectItem>
                    <SelectItem value="large">Grande</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Settings (Admin only) */}
        {isAdmin && (
          <TabsContent value="system" className="space-y-6">
            <Card className="gym-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-gym-primary" />
                  Configuración del Sistema
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="gym-name">Nombre del Gimnasio</Label>
                  <Input id="gym-name" value="FitPro" />
                </div>

                <div>
                  <Label htmlFor="operating-hours">Horarios de Operación</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="open-time">Apertura</Label>
                      <Input id="open-time" type="time" value="06:00" />
                    </div>
                    <div>
                      <Label htmlFor="close-time">Cierre</Label>
                      <Input id="close-time" type="time" value="22:00" />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="max-capacity">Capacidad Máxima</Label>
                  <Input id="max-capacity" type="number" value="120" />
                </div>

                <div>
                  <Label htmlFor="session-duration">
                    Duración de Sesión por Defecto (minutos)
                  </Label>
                  <Input id="session-duration" type="number" value="60" />
                </div>
              </CardContent>
            </Card>

            <Card className="gym-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-gym-primary" />
                  Gestión de Usuarios
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Registro Automático</Label>
                    <p className="text-sm text-gray-600">
                      Permitir que los usuarios se registren automáticamente
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Aprobación Manual</Label>
                    <p className="text-sm text-gray-600">
                      Requerir aprobación manual para nuevos miembros
                    </p>
                  </div>
                  <Switch />
                </div>

                <div>
                  <Label htmlFor="trial-period">Período de Prueba (días)</Label>
                  <Input id="trial-period" type="number" value="7" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Privacy Settings */}
        {!isAdmin && (
          <TabsContent value="privacy" className="space-y-6">
            <Card className="gym-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-gym-primary" />
                  Configuración de Privacidad
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Perfil Público</Label>
                    <p className="text-sm text-gray-600">
                      Permitir que otros miembros vean tu perfil
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Estadísticas Visibles</Label>
                    <p className="text-sm text-gray-600">
                      Mostrar tus estadísticas en rankings públicos
                    </p>
                  </div>
                  <Switch />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Compartir Progreso</Label>
                    <p className="text-sm text-gray-600">
                      Permitir compartir tu progreso con coaches
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-4">Gestión de Datos</h4>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <Globe className="mr-2 h-4 w-4" />
                      Descargar mis datos
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-red-600 hover:text-red-600"
                    >
                      <Shield className="mr-2 h-4 w-4" />
                      Eliminar mi cuenta
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default Settings;
