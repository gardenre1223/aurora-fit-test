import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Activity,
  Award,
  Edit,
  Camera,
} from "lucide-react";
import { authManager } from "@/lib/auth";

const Profile = () => {
  const user = authManager.getCurrentUser();
  const currentLocation = authManager.getCurrentLocation();

  if (!user) return null;

  const getRoleLabel = (role: string) => {
    switch (role) {
      case "administrator":
        return "Administrador";
      case "coach":
        return "Coach";
      case "user":
        return "Usuario";
      default:
        return role;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <User className="h-8 w-8 text-aurora-primary" />
            Mi Perfil
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            Gestiona tu información personal y configuraciones
          </p>
        </div>
        <Button className="aurora-button-primary gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
          <Edit className="h-4 w-4" />
          Editar Perfil
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card className="aurora-card-glow">
          <CardHeader className="text-center">
            <div className="relative mx-auto mb-4">
              <Avatar className="h-24 w-24 ring-4 ring-aurora-accent">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="aurora-gradient text-white text-2xl">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <Button
                size="icon"
                variant="outline"
                className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
            <CardTitle className="text-xl">{user.name}</CardTitle>
            <Badge
              variant="secondary"
              className="bg-aurora-accent text-aurora-primary mx-auto px-4 py-1"
            >
              {getRoleLabel(user.role)}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-gray-500" />
              <span>{user.email}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-gray-500" />
              <span>+52 555 123 4567</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <MapPin className="h-4 w-4 text-gray-500" />
              <span>{currentLocation?.name}</span>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Calendar className="h-4 w-4 text-gray-500" />
              <span>Miembro desde enero 2024</span>
            </div>
          </CardContent>
        </Card>

        {/* Details and Stats */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="info" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="info">Información</TabsTrigger>
              <TabsTrigger value="stats">Estadísticas</TabsTrigger>
              <TabsTrigger value="achievements">Logros</TabsTrigger>
            </TabsList>

            {/* Information Tab */}
            <TabsContent value="info" className="space-y-6">
              <Card className="aurora-card">
                <CardHeader>
                  <CardTitle>Información Personal</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">Nombre</Label>
                      <Input
                        id="firstName"
                        value={user.name.split(" ")[0]}
                        disabled
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Apellido</Label>
                      <Input
                        id="lastName"
                        value={user.name.split(" ").slice(1).join(" ")}
                        disabled
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" value={user.email} disabled />
                    </div>
                    <div>
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input id="phone" value="+52 555 123 4567" disabled />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {user.role === "user" && (
                <Card className="gym-card">
                  <CardHeader>
                    <CardTitle>Información Física</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="height">Altura (cm)</Label>
                        <Input id="height" value="175" disabled />
                      </div>
                      <div>
                        <Label htmlFor="weight">Peso (kg)</Label>
                        <Input id="weight" value="72.5" disabled />
                      </div>
                      <div>
                        <Label htmlFor="age">Edad</Label>
                        <Input id="age" value="28" disabled />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Statistics Tab */}
            <TabsContent value="stats" className="space-y-6">
              <Card className="aurora-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5 text-aurora-primary" />
                    Estadísticas Generales
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-aurora-primary mb-2">
                        {user.role === "user" ? "45" : "128"}
                      </div>
                      <p className="text-sm text-gray-600">
                        {user.role === "user"
                          ? "Sesiones Completadas"
                          : "Clientes Atendidos"}
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-aurora-secondary mb-2">
                        {user.role === "user" ? "3" : "24"}
                      </div>
                      <p className="text-sm text-gray-600">
                        {user.role === "user"
                          ? "Meses Activo"
                          : "Planes Creados"}
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-aurora-tertiary mb-2">
                        {user.role === "user" ? "8.5" : "4.8"}
                      </div>
                      <p className="text-sm text-gray-600">
                        {user.role === "user"
                          ? "Kg Perdidos"
                          : "Calificación Promedio"}
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-aurora-quaternary mb-2">
                        {user.role === "user" ? "92%" : "96%"}
                      </div>
                      <p className="text-sm text-gray-600">
                        {user.role === "user" ? "Adherencia" : "Satisfacción"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements" className="space-y-6">
              <Card className="gym-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-gym-primary" />
                    Logros y Reconocimientos
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    {
                      title: "Primera Semana Completa",
                      description:
                        "Completaste 7 días seguidos de entrenamiento",
                      date: "Enero 2024",
                      icon: "🏃‍♂️",
                    },
                    {
                      title: "Meta de Peso Alcanzada",
                      description: "Lograste tu objetivo de pérdida de peso",
                      date: "Febrero 2024",
                      icon: "🎯",
                    },
                    {
                      title: "Constancia",
                      description: "30 días consecutivos de entrenamiento",
                      date: "Marzo 2024",
                      icon: "💪",
                    },
                  ].map((achievement, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4 p-4 border rounded-lg bg-gradient-to-r from-gym-accent to-white"
                    >
                      <div className="text-2xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">
                          {achievement.title}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {achievement.description}
                        </p>
                        <p className="text-xs text-gym-primary font-medium">
                          {achievement.date}
                        </p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;
