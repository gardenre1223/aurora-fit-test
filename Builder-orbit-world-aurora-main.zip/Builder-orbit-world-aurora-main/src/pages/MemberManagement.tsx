import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Users,
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  Trash2,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  Clock,
  Calendar,
  CreditCard,
  Activity,
  TrendingUp,
  UserPlus,
  Bell,
  Mail,
  Phone,
  MapPin,
  Dumbbell,
  Apple,
} from "lucide-react";
import { authManager } from "@/lib/auth";

// Extended member interface
interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  membershipType: "basic" | "premium" | "vip";
  status: "active" | "inactive" | "suspended" | "expired";
  joinDate: string;
  lastVisit: string;
  checkInTime?: string;
  checkOutTime?: string;
  isCurrentlyInGym: boolean;

  // Payment information
  lastPayment: string;
  nextPayment: string;
  monthlyFee: number;
  paymentStatus: "current" | "overdue" | "pending";
  daysUntilExpiry: number;

  // Training information
  hasTrainingPlan: boolean;
  trainingsThisMonth: number;
  assignedCoach?: string;
  lastTraining?: string;

  // Nutrition
  hasNutritionPlan: boolean;
  assignedNutritionist?: string;

  // Additional info
  emergencyContact: string;
  medicalNotes?: string;
  goals: string[];
  totalVisits: number;
  averageVisitsPerWeek: number;
  assignedLocations: string[]; // Array of location IDs
}

const MemberManagement = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterMembership, setFilterMembership] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isLocationManagementOpen, setIsLocationManagementOpen] =
    useState(false);
  const [memberForLocationEdit, setMemberForLocationEdit] =
    useState<Member | null>(null);

  const user = authManager.getCurrentUser();

  // Available locations for assignment
  const availableLocations = [
    {
      id: "1",
      name: "AuroraFit Centro",
      address: "Av. Reforma 123",
      city: "Ciudad de México",
      isActive: true,
    },
    {
      id: "2",
      name: "AuroraFit Polanco",
      address: "Av. Masaryk 456",
      city: "Ciudad de México",
      isActive: true,
    },
    {
      id: "3",
      name: "AuroraFit Santa Fe",
      address: "Av. Santa Fe 789",
      city: "Ciudad de México",
      isActive: true,
    },
    {
      id: "4",
      name: "AuroraFit Condesa",
      address: "Av. Insurgentes 321",
      city: "Ciudad de México",
      isActive: false,
    },
    {
      id: "5",
      name: "AuroraFit Roma Norte",
      address: "Calle Orizaba 567",
      city: "Ciudad de México",
      isActive: true,
    },
  ];

  // Mock members data
  const mockMembers: Member[] = [
    {
      id: "1",
      name: "Ana García",
      email: "ana.garcia@email.com",
      phone: "+52 555 123 4567",
      avatar:
        "https://images.unsplash.com/photo-1494790108755-2616b612b5bc?w=100&h=100&fit=crop&crop=face",
      membershipType: "premium",
      status: "active",
      joinDate: "2024-01-15",
      lastVisit: "2024-01-15",
      checkInTime: "08:30",
      isCurrentlyInGym: true,
      lastPayment: "2024-01-01",
      nextPayment: "2024-02-01",
      monthlyFee: 1200,
      paymentStatus: "current",
      daysUntilExpiry: 17,
      hasTrainingPlan: true,
      trainingsThisMonth: 12,
      assignedCoach: "María González",
      lastTraining: "2024-01-14",
      hasNutritionPlan: true,
      assignedNutritionist: "Dr. Ana Ruiz",
      emergencyContact: "+52 555 987 6543",
      goals: ["Pérdida de peso", "Tonificación"],
      totalVisits: 45,
      averageVisitsPerWeek: 3.2,
      assignedLocations: ["1", "2"], // Multiple locations
    },
    {
      id: "2",
      name: "Carlos Mendoza",
      email: "carlos.mendoza@email.com",
      phone: "+52 555 234 5678",
      membershipType: "basic",
      status: "active",
      joinDate: "2023-11-20",
      lastVisit: "2024-01-14",
      isCurrentlyInGym: false,
      lastPayment: "2023-12-20",
      nextPayment: "2024-01-20",
      monthlyFee: 800,
      paymentStatus: "overdue",
      daysUntilExpiry: -5,
      hasTrainingPlan: false,
      trainingsThisMonth: 8,
      hasNutritionPlan: false,
      emergencyContact: "+52 555 876 5432",
      goals: ["Ganar músculo"],
      totalVisits: 32,
      averageVisitsPerWeek: 2.1,
      assignedLocations: ["1"], // Single location
    },
    {
      id: "3",
      name: "Sofia López",
      email: "sofia.lopez@email.com",
      phone: "+52 555 345 6789",
      avatar:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
      membershipType: "vip",
      status: "active",
      joinDate: "2023-09-10",
      lastVisit: "2024-01-15",
      checkInTime: "18:45",
      isCurrentlyInGym: true,
      lastPayment: "2024-01-10",
      nextPayment: "2024-02-10",
      monthlyFee: 2000,
      paymentStatus: "current",
      daysUntilExpiry: 26,
      hasTrainingPlan: true,
      trainingsThisMonth: 16,
      assignedCoach: "Roberto Silva",
      lastTraining: "2024-01-15",
      hasNutritionPlan: true,
      assignedNutritionist: "Lic. María Pérez",
      emergencyContact: "+52 555 765 4321",
      medicalNotes: "Alergia a frutos secos",
      goals: ["Resistencia", "Competición"],
      totalVisits: 89,
      averageVisitsPerWeek: 4.5,
      assignedLocations: ["1", "2", "3"], // VIP member with access to multiple locations
    },
    {
      id: "4",
      name: "Roberto Silva",
      email: "roberto.silva@email.com",
      phone: "+52 555 456 7890",
      membershipType: "premium",
      status: "suspended",
      joinDate: "2023-08-05",
      lastVisit: "2024-01-10",
      isCurrentlyInGym: false,
      lastPayment: "2023-11-05",
      nextPayment: "2023-12-05",
      monthlyFee: 1200,
      paymentStatus: "overdue",
      daysUntilExpiry: -45,
      hasTrainingPlan: true,
      trainingsThisMonth: 0,
      assignedCoach: "María González",
      hasNutritionPlan: false,
      emergencyContact: "+52 555 654 3210",
      goals: ["Rehabilitación"],
      totalVisits: 28,
      averageVisitsPerWeek: 1.8,
      assignedLocations: ["2"], // Polanco only
    },
    {
      id: "5",
      name: "Elena Rodríguez",
      email: "elena.rodriguez@email.com",
      phone: "+52 555 567 8901",
      membershipType: "basic",
      status: "active",
      joinDate: "2024-01-01",
      lastVisit: "2024-01-15",
      isCurrentlyInGym: false,
      lastPayment: "2024-01-01",
      nextPayment: "2024-02-01",
      monthlyFee: 800,
      paymentStatus: "current",
      daysUntilExpiry: 17,
      hasTrainingPlan: false,
      trainingsThisMonth: 10,
      hasNutritionPlan: false,
      emergencyContact: "+52 555 543 2109",
      goals: ["Estado físico general"],
      totalVisits: 15,
      averageVisitsPerWeek: 3.8,
      assignedLocations: ["1", "5"], // Centro and Roma Norte
    },
  ];

  const [members, setMembers] = useState<Member[]>(mockMembers);

  // Filtered and sorted members
  const filteredMembers = useMemo(() => {
    return members
      .filter((member) => {
        const matchesSearch =
          member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          member.email.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesStatus =
          filterStatus === "all" || member.status === filterStatus;
        const matchesMembership =
          filterMembership === "all" ||
          member.membershipType === filterMembership;
        return matchesSearch && matchesStatus && matchesMembership;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "name":
            return a.name.localeCompare(b.name);
          case "joinDate":
            return (
              new Date(b.joinDate).getTime() - new Date(a.joinDate).getTime()
            );
          case "lastVisit":
            return (
              new Date(b.lastVisit).getTime() - new Date(a.lastVisit).getTime()
            );
          case "paymentStatus":
            const statusOrder = { overdue: 0, pending: 1, current: 2 };
            return statusOrder[a.paymentStatus] - statusOrder[b.paymentStatus];
          default:
            return 0;
        }
      });
  }, [members, searchTerm, filterStatus, filterMembership, sortBy]);

  // Statistics
  const stats = useMemo(() => {
    const activeMembers = members.filter((m) => m.status === "active").length;
    const currentlyInGym = members.filter((m) => m.isCurrentlyInGym).length;
    const overduePayments = members.filter(
      (m) => m.paymentStatus === "overdue",
    ).length;
    const totalRevenue = members
      .filter((m) => m.paymentStatus === "current")
      .reduce((sum, m) => sum + m.monthlyFee, 0);

    return {
      activeMembers,
      currentlyInGym,
      overduePayments,
      totalRevenue,
      totalMembers: members.length,
    };
  }, [members]);

  const getStatusBadge = (status: string, paymentStatus?: string) => {
    if (paymentStatus === "overdue") {
      return <Badge variant="destructive">Pago Vencido</Badge>;
    }

    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">Activo</Badge>;
      case "inactive":
        return <Badge variant="secondary">Inactivo</Badge>;
      case "suspended":
        return <Badge variant="destructive">Suspendido</Badge>;
      case "expired":
        return (
          <Badge className="bg-orange-100 text-orange-800">Expirado</Badge>
        );
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getMembershipBadge = (type: string) => {
    switch (type) {
      case "basic":
        return <Badge className="bg-blue-100 text-blue-800">Básico</Badge>;
      case "premium":
        return (
          <Badge className="bg-aurora-accent text-aurora-primary">
            Premium
          </Badge>
        );
      case "vip":
        return <Badge className="aurora-gradient text-white">VIP</Badge>;
      default:
        return <Badge variant="secondary">{type}</Badge>;
    }
  };

  const handleViewMember = (member: Member) => {
    setSelectedMember(member);
    setIsDetailModalOpen(true);
  };

  const handleManageLocations = (member: Member) => {
    setMemberForLocationEdit(member);
    setIsLocationManagementOpen(true);
  };

  const getLocationName = (locationId: string) => {
    return (
      availableLocations.find((loc) => loc.id === locationId)?.name ||
      "Sede desconocida"
    );
  };

  const handleUpdateMemberLocations = (
    memberToUpdate: Member,
    newLocationIds: string[],
  ) => {
    setMembers((prevMembers) =>
      prevMembers.map((member) =>
        member.id === memberToUpdate.id
          ? { ...member, assignedLocations: newLocationIds }
          : member,
      ),
    );
    setIsLocationManagementOpen(false);
    setMemberForLocationEdit(null);
  };

  if (!user || user.role !== "administrator") {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Acceso Restringido</h2>
          <p className="text-gray-600">
            Solo los administradores pueden acceder a esta sección.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <Users className="h-8 w-8 text-aurora-primary" />
            Gestión de Miembros
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            Administra todos los miembros, pagos y asistencias del gimnasio
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar
          </Button>
          <Button variant="outline" className="gap-2">
            <Upload className="h-4 w-4" />
            Importar
          </Button>
          <Dialog open={isAddMemberOpen} onOpenChange={setIsAddMemberOpen}>
            <DialogTrigger asChild>
              <Button className="aurora-button-primary gap-2 shadow-lg hover:shadow-xl transition-all duration-300">
                <UserPlus className="h-4 w-4" />
                Nuevo Miembro
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Registrar Nuevo Miembro</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div>
                  <Label htmlFor="name">Nombre Completo</Label>
                  <Input id="name" placeholder="Ej. Ana García López" />
                </div>
                <div>
                  <Label htmlFor="email">Correo Electrónico</Label>
                  <Input id="email" type="email" placeholder="ana@email.com" />
                </div>
                <div>
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input id="phone" placeholder="+52 555 123 4567" />
                </div>
                <div>
                  <Label htmlFor="emergency">Contacto de Emergencia</Label>
                  <Input id="emergency" placeholder="+52 555 987 6543" />
                </div>
                <div>
                  <Label htmlFor="membership">Tipo de Membresía</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Básico - $800/mes</SelectItem>
                      <SelectItem value="premium">
                        Premium - $1,200/mes
                      </SelectItem>
                      <SelectItem value="vip">VIP - $2,000/mes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="coach">Coach Asignado (Opcional)</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Sin coach asignado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="maria">María González</SelectItem>
                      <SelectItem value="roberto">Roberto Silva</SelectItem>
                      <SelectItem value="luis">Luis García</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label htmlFor="goals">Objetivos</Label>
                  <Textarea
                    id="goals"
                    placeholder="Ej. Pérdida de peso, ganar músculo, mejorar resistencia..."
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="medical">Notas Médicas (Opcional)</Label>
                  <Textarea
                    id="medical"
                    placeholder="Alergias, lesiones previas, medicamentos..."
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => setIsAddMemberOpen(false)}
                >
                  Cancelar
                </Button>
                <Button
                  className="aurora-button-primary"
                  onClick={() => setIsAddMemberOpen(false)}
                >
                  Registrar Miembro
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Miembros</p>
                <p className="text-2xl font-bold">{stats.totalMembers}</p>
              </div>
              <Users className="h-8 w-8 text-aurora-primary" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Miembros Activos</p>
                <p className="text-2xl font-bold text-green-600">
                  {stats.activeMembers}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">En el Gimnasio</p>
                <p className="text-2xl font-bold text-blue-600">
                  {stats.currentlyInGym}
                </p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pagos Vencidos</p>
                <p className="text-2xl font-bold text-red-600">
                  {stats.overduePayments}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="aurora-card-glow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ingresos Mensuales</p>
                <p className="text-2xl font-bold text-aurora-primary">
                  ${stats.totalRevenue.toLocaleString()}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-aurora-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="aurora-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar miembros por nombre o email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los estados</SelectItem>
                <SelectItem value="active">Activos</SelectItem>
                <SelectItem value="inactive">Inactivos</SelectItem>
                <SelectItem value="suspended">Suspendidos</SelectItem>
                <SelectItem value="expired">Expirados</SelectItem>
              </SelectContent>
            </Select>
            <Select
              value={filterMembership}
              onValueChange={setFilterMembership}
            >
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las membresías</SelectItem>
                <SelectItem value="basic">Básico</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
                <SelectItem value="vip">VIP</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Ordenar por nombre</SelectItem>
                <SelectItem value="joinDate">Fecha de registro</SelectItem>
                <SelectItem value="lastVisit">Última visita</SelectItem>
                <SelectItem value="paymentStatus">Estado de pago</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Members Table */}
      <Card className="aurora-card">
        <CardHeader>
          <CardTitle>Lista de Miembros ({filteredMembers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Miembro</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Membresía</TableHead>
                  <TableHead>Última Visita</TableHead>
                  <TableHead>Pago</TableHead>
                  <TableHead>Próximo Pago</TableHead>
                  <TableHead>Coach</TableHead>
                  <TableHead>Entrenamientos</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMembers.map((member) => (
                  <TableRow
                    key={member.id}
                    className="hover:bg-aurora-accent/20"
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback>
                            {member.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{member.name}</p>
                          <p className="text-sm text-gray-600">
                            {member.email}
                          </p>
                          {member.isCurrentlyInGym && (
                            <Badge className="bg-green-100 text-green-800 text-xs mt-1">
                              En el gimnasio - {member.checkInTime}
                            </Badge>
                          )}
                          <div className="flex flex-wrap gap-1 mt-1">
                            {member.assignedLocations
                              .slice(0, 2)
                              .map((locationId) => (
                                <Badge
                                  key={locationId}
                                  variant="outline"
                                  className="text-xs bg-aurora-accent text-aurora-primary"
                                >
                                  {getLocationName(locationId).replace(
                                    "AuroraFit ",
                                    "",
                                  )}
                                </Badge>
                              ))}
                            {member.assignedLocations.length > 2 && (
                              <Badge variant="outline" className="text-xs">
                                +{member.assignedLocations.length - 2} más
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(member.status, member.paymentStatus)}
                    </TableCell>
                    <TableCell>
                      {getMembershipBadge(member.membershipType)}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p>{new Date(member.lastVisit).toLocaleDateString()}</p>
                        <p className="text-gray-600">
                          {member.totalVisits} visitas totales
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p className="font-medium">${member.monthlyFee}</p>
                        <p className="text-gray-600">
                          Pagó:{" "}
                          {new Date(member.lastPayment).toLocaleDateString()}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p>
                          {new Date(member.nextPayment).toLocaleDateString()}
                        </p>
                        <p
                          className={`font-medium ${
                            member.daysUntilExpiry < 0
                              ? "text-red-600"
                              : member.daysUntilExpiry < 7
                                ? "text-orange-600"
                                : "text-gray-600"
                          }`}
                        >
                          {member.daysUntilExpiry < 0
                            ? `${Math.abs(member.daysUntilExpiry)} días vencido`
                            : `${member.daysUntilExpiry} días restantes`}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      {member.assignedCoach ? (
                        <div className="text-sm">
                          <p className="font-medium">{member.assignedCoach}</p>
                          {member.hasTrainingPlan && (
                            <Badge className="bg-blue-100 text-blue-800 text-xs">
                              Con plan
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-400">Sin asignar</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <p className="font-medium">
                          {member.trainingsThisMonth} este mes
                        </p>
                        <p className="text-gray-600">
                          {member.averageVisitsPerWeek} prom/semana
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                          <DropdownMenuItem
                            onClick={() => handleViewMember(member)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            Ver detalles
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" />
                            Enviar email
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Bell className="mr-2 h-4 w-4" />
                            Enviar notificación
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <CreditCard className="mr-2 h-4 w-4" />
                            Procesar pago
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Dumbbell className="mr-2 h-4 w-4" />
                            Asignar coach
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleManageLocations(member)}
                          >
                            <Building2 className="mr-2 h-4 w-4" />
                            Gestionar sedes
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Suspender miembro
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Location Management Modal */}
      <Dialog
        open={isLocationManagementOpen}
        onOpenChange={setIsLocationManagementOpen}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Building2 className="h-6 w-6 text-aurora-primary" />
              Gestionar Sedes - {memberForLocationEdit?.name}
            </DialogTitle>
          </DialogHeader>

          {memberForLocationEdit && (
            <LocationAssignmentForm
              member={memberForLocationEdit}
              availableLocations={availableLocations}
              onUpdate={handleUpdateMemberLocations}
              onCancel={() => setIsLocationManagementOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Member Detail Modal */}
      <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage
                  src={selectedMember?.avatar}
                  alt={selectedMember?.name}
                />
                <AvatarFallback>
                  {selectedMember?.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-xl font-bold">{selectedMember?.name}</h2>
                <p className="text-gray-600">{selectedMember?.email}</p>
              </div>
            </DialogTitle>
          </DialogHeader>

          {selectedMember && (
            <Tabs defaultValue="overview" className="mt-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Resumen</TabsTrigger>
                <TabsTrigger value="training">Entrenamientos</TabsTrigger>
                <TabsTrigger value="payments">Pagos</TabsTrigger>
                <TabsTrigger value="history">Historial</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">
                        Información Personal
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-gray-500" />
                        <span>{selectedMember.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-500" />
                        <span>
                          Miembro desde{" "}
                          {new Date(
                            selectedMember.joinDate,
                          ).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-gray-500" />
                        <span>
                          Emergencia: {selectedMember.emergencyContact}
                        </span>
                      </div>
                      {selectedMember.medicalNotes && (
                        <div className="p-3 bg-yellow-50 rounded-lg">
                          <p className="text-sm font-medium text-yellow-800">
                            Notas Médicas:
                          </p>
                          <p className="text-sm text-yellow-700">
                            {selectedMember.medicalNotes}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Estado Actual</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span>Estado:</span>
                        {getStatusBadge(selectedMember.status)}
                      </div>
                      <div className="flex justify-between">
                        <span>Membresía:</span>
                        {getMembershipBadge(selectedMember.membershipType)}
                      </div>
                      <div className="flex justify-between">
                        <span>En gimnasio:</span>
                        <Badge
                          className={
                            selectedMember.isCurrentlyInGym
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {selectedMember.isCurrentlyInGym
                            ? `Sí - ${selectedMember.checkInTime}`
                            : "No"}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Última visita:</span>
                        <span>
                          {new Date(
                            selectedMember.lastVisit,
                          ).toLocaleDateString()}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      Objetivos y Planes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium mb-2">Objetivos:</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedMember.goals.map((goal, index) => (
                            <Badge key={index} variant="outline">
                              {goal}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span>Plan de entrenamiento:</span>
                          <Badge
                            className={
                              selectedMember.hasTrainingPlan
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }
                          >
                            {selectedMember.hasTrainingPlan
                              ? "Activo"
                              : "Sin plan"}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Plan nutricional:</span>
                          <Badge
                            className={
                              selectedMember.hasNutritionPlan
                                ? "bg-green-100 text-green-800"
                                : "bg-gray-100 text-gray-800"
                            }
                          >
                            {selectedMember.hasNutritionPlan
                              ? "Activo"
                              : "Sin plan"}
                          </Badge>
                        </div>
                        {selectedMember.assignedCoach && (
                          <div className="flex items-center justify-between">
                            <span>Coach asignado:</span>
                            <span className="font-medium">
                              {selectedMember.assignedCoach}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="training">
                <Card>
                  <CardHeader>
                    <CardTitle>Estadísticas de Entrenamiento</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-6 mb-6">
                      <div className="text-center">
                        <p className="text-3xl font-bold text-aurora-primary">
                          {selectedMember.trainingsThisMonth}
                        </p>
                        <p className="text-sm text-gray-600">
                          Entrenamientos este mes
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-aurora-secondary">
                          {selectedMember.totalVisits}
                        </p>
                        <p className="text-sm text-gray-600">
                          Total de visitas
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-3xl font-bold text-aurora-tertiary">
                          {selectedMember.averageVisitsPerWeek}
                        </p>
                        <p className="text-sm text-gray-600">
                          Promedio por semana
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="payments">
                <Card>
                  <CardHeader>
                    <CardTitle>Información de Pagos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600">Cuota mensual</p>
                          <p className="text-2xl font-bold">
                            ${selectedMember.monthlyFee}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Último pago</p>
                          <p className="font-medium">
                            {new Date(
                              selectedMember.lastPayment,
                            ).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Próximo pago</p>
                          <p className="font-medium">
                            {new Date(
                              selectedMember.nextPayment,
                            ).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm text-gray-600">
                            Estado del pago
                          </p>
                          {getStatusBadge(
                            selectedMember.status,
                            selectedMember.paymentStatus,
                          )}
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">
                            Días hasta vencimiento
                          </p>
                          <p
                            className={`font-medium ${selectedMember.daysUntilExpiry < 0 ? "text-red-600" : selectedMember.daysUntilExpiry < 7 ? "text-orange-600" : "text-green-600"}`}
                          >
                            {selectedMember.daysUntilExpiry < 0
                              ? `${Math.abs(selectedMember.daysUntilExpiry)} días vencido`
                              : `${selectedMember.daysUntilExpiry} días restantes`}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="history">
                <Card>
                  <CardHeader>
                    <CardTitle>Historial de Actividades</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          date: "2024-01-15",
                          action: "Check-in",
                          time: "08:30",
                          type: "gym",
                        },
                        {
                          date: "2024-01-14",
                          action: "Entrenamiento completado",
                          time: "09:30",
                          type: "training",
                        },
                        {
                          date: "2024-01-10",
                          action: "Pago procesado",
                          time: "14:20",
                          type: "payment",
                        },
                        {
                          date: "2024-01-08",
                          action: "Plan nutricional actualizado",
                          time: "16:00",
                          type: "nutrition",
                        },
                      ].map((activity, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-4 p-3 border rounded-lg"
                        >
                          <div
                            className={`p-2 rounded-full ${
                              activity.type === "gym"
                                ? "bg-blue-100 text-blue-600"
                                : activity.type === "training"
                                  ? "bg-green-100 text-green-600"
                                  : activity.type === "payment"
                                    ? "bg-purple-100 text-purple-600"
                                    : "bg-orange-100 text-orange-600"
                            }`}
                          >
                            {activity.type === "gym" && (
                              <Activity className="h-4 w-4" />
                            )}
                            {activity.type === "training" && (
                              <Dumbbell className="h-4 w-4" />
                            )}
                            {activity.type === "payment" && (
                              <CreditCard className="h-4 w-4" />
                            )}
                            {activity.type === "nutrition" && (
                              <Apple className="h-4 w-4" />
                            )}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{activity.action}</p>
                            <p className="text-sm text-gray-600">
                              {activity.date} - {activity.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Location Assignment Form Component
interface LocationAssignmentFormProps {
  member: Member;
  availableLocations: Array<{
    id: string;
    name: string;
    address: string;
    city: string;
    isActive: boolean;
  }>;
  onUpdate: (member: Member, newLocationIds: string[]) => void;
  onCancel: () => void;
}

const LocationAssignmentForm = ({
  member,
  availableLocations,
  onUpdate,
  onCancel,
}: LocationAssignmentFormProps) => {
  const [selectedLocations, setSelectedLocations] = useState<string[]>(
    member.assignedLocations || [],
  );

  const handleLocationToggle = (locationId: string) => {
    setSelectedLocations((prev) =>
      prev.includes(locationId)
        ? prev.filter((id) => id !== locationId)
        : [...prev, locationId],
    );
  };

  const handleSave = () => {
    onUpdate(member, selectedLocations);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div>
          <h4 className="font-semibold text-gray-900 mb-2">
            Sedes Actuales del {member.role === "user" ? "Miembro" : "Coach"}
          </h4>
          <p className="text-sm text-gray-600 mb-4">
            Selecciona las sedes a las que {member.name} tendrá acceso. Los
            miembros VIP pueden tener acceso a múltiples sedes.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {availableLocations.map((location) => (
            <div
              key={location.id}
              className={`flex items-center justify-between p-4 border rounded-xl transition-all duration-300 ${
                selectedLocations.includes(location.id)
                  ? "border-aurora-primary bg-aurora-accent/30"
                  : "border-gray-200 hover:border-gray-300"
              } ${!location.isActive ? "opacity-50" : ""}`}
            >
              <div className="flex items-center gap-3">
                <Checkbox
                  checked={selectedLocations.includes(location.id)}
                  onCheckedChange={() => handleLocationToggle(location.id)}
                  disabled={!location.isActive}
                />
                <div>
                  <h5 className="font-medium text-gray-900 flex items-center gap-2">
                    {location.name}
                    {!location.isActive && (
                      <Badge variant="secondary" className="text-xs">
                        Inactiva
                      </Badge>
                    )}
                  </h5>
                  <p className="text-sm text-gray-600">
                    {location.address}, {location.city}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {selectedLocations.includes(location.id) && (
                  <Badge className="bg-green-100 text-green-800">
                    Asignada
                  </Badge>
                )}
                <MapPin className="h-4 w-4 text-gray-400" />
              </div>
            </div>
          ))}
        </div>

        {selectedLocations.length === 0 && (
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
              <div>
                <h5 className="font-medium text-yellow-800">
                  Sin sedes asignadas
                </h5>
                <p className="text-sm text-yellow-700">
                  Este {member.role === "user" ? "miembro" : "coach"} no tendrá
                  acceso a ninguna sede. Selecciona al menos una sede para que
                  pueda usar los servicios.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-3">
          <h5 className="font-medium text-gray-900">Resumen de Asignación:</h5>
          <div className="flex flex-wrap gap-2">
            {selectedLocations.length > 0 ? (
              selectedLocations.map((locationId) => {
                const location = availableLocations.find(
                  (loc) => loc.id === locationId,
                );
                return (
                  <Badge
                    key={locationId}
                    className="bg-aurora-accent text-aurora-primary px-3 py-1"
                  >
                    {location?.name.replace("AuroraFit ", "")}
                  </Badge>
                );
              })
            ) : (
              <Badge variant="secondary">No hay sedes seleccionadas</Badge>
            )}
          </div>
          <p className="text-sm text-gray-600">
            Total: {selectedLocations.length} sede
            {selectedLocations.length !== 1 ? "s" : ""} asignada
            {selectedLocations.length !== 1 ? "s" : ""}
          </p>
        </div>
      </div>

      <div className="flex gap-3 pt-4 border-t">
        <Button variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button
          onClick={handleSave}
          className="flex-1 aurora-button-primary"
          disabled={selectedLocations.length === 0}
        >
          <Building2 className="h-4 w-4 mr-2" />
          Guardar Asignaciones
        </Button>
      </div>
    </div>
  );
};

export default MemberManagement;
