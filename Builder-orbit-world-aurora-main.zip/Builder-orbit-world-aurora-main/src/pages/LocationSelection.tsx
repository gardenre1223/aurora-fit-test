import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  MapPin,
  Building2,
  Users,
  ArrowRight,
  LogOut,
  CheckCircle,
} from "lucide-react";
import { authManager, type Location } from "@/lib/auth";

const LocationSelection = () => {
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(
    null,
  );
  const navigate = useNavigate();
  const user = authManager.getCurrentUser();

  if (!user) {
    navigate("/login");
    return null;
  }

  const handleLocationSelect = (location: Location) => {
    setSelectedLocation(location);
  };

  const handleContinue = () => {
    if (selectedLocation) {
      authManager.setCurrentLocation(selectedLocation);
      navigate("/dashboard");
    }
  };

  const handleLogout = () => {
    authManager.logout();
    navigate("/login");
  };

  const activeLocations = user.locations.filter((loc) => loc.isActive);

  return (
    <div className="min-h-screen bg-gradient-to-br from-aurora-accent via-white to-purple-50 p-4 relative overflow-hidden">
      {/* Aurora Background Effect */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-10 right-10 w-72 h-72 bg-aurora-gradient rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-64 h-64 bg-aurora-gradient-alt rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-5xl mx-auto space-y-8 animate-fade-in relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="bg-gym-primary text-white">
                {user.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                ¡Bienvenido, {user.name}!
              </h1>
              <p className="text-gray-600">
                Selecciona la sede a la que deseas acceder
              </p>
            </div>
          </div>
          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="h-4 w-4" />
            Cerrar Sesión
          </Button>
        </div>

        {/* User Role Badge */}
        <div className="flex items-center gap-3">
          <Badge
            variant="secondary"
            className="aurora-gradient text-white px-4 py-2 text-sm font-medium"
          >
            {user.role === "administrator" && "Administrador"}
            {user.role === "coach" && "Coach"}
            {user.role === "user" && "Usuario"}
          </Badge>
          <span className="text-sm text-gray-600">
            Tienes acceso a {activeLocations.length} sede
            {activeLocations.length !== 1 ? "s" : ""}
          </span>
        </div>

        {/* Locations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeLocations.map((location) => (
            <Card
              key={location.id}
              className={`aurora-card cursor-pointer transition-all duration-300 hover:scale-105 ${
                selectedLocation?.id === location.id
                  ? "ring-2 ring-aurora-primary bg-aurora-accent shadow-xl"
                  : "hover:shadow-lg"
              }`}
              onClick={() => handleLocationSelect(location)}
            >
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-aurora-primary" />
                    {location.name}
                  </div>
                  {selectedLocation?.id === location.id && (
                    <CheckCircle className="h-5 w-5 text-aurora-primary" />
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    {location.address}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Users className="h-4 w-4" />
                    {location.city}
                  </div>
                </div>

                {/* Mock stats */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-aurora-primary">
                      {Math.floor(Math.random() * 50) + 20}
                    </p>
                    <p className="text-xs text-gray-600">Miembros activos</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-aurora-secondary">
                      {Math.floor(Math.random() * 10) + 5}
                    </p>
                    <p className="text-xs text-gray-600">Coaches</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Continue Button */}
        {selectedLocation && (
          <div className="flex justify-center animate-fade-in">
            <Button
              onClick={handleContinue}
              className="aurora-button-primary h-14 px-10 gap-3 text-lg font-medium shadow-lg hover:shadow-xl"
              size="lg"
            >
              Continuar a {selectedLocation.name}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* No locations message */}
        {activeLocations.length === 0 && (
          <Card className="gym-card text-center py-12">
            <CardContent>
              <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No hay sedes disponibles
              </h3>
              <p className="text-gray-600">
                Contacta al administrador para obtener acceso a una sede.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default LocationSelection;
