import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Dumbbell,
  TrendingUp,
  Calendar,
  Clock,
  Target,
  Award,
  Activity,
  Plus,
  ArrowRight,
  Zap,
  Heart,
  Flame,
  Star,
  BarChart3,
  MapPin,
} from "lucide-react";
import { authManager, getUserPermissions } from "@/lib/auth";

const DashboardHome = () => {
  const navigate = useNavigate();
  const [realTimeMetrics, setRealTimeMetrics] = useState({
    heartRate: 85,
    caloriesBurned: 245,
    activeMembers: 67,
    energyLevel: 78,
  });

  const user = authManager.getCurrentUser();
  const currentLocation = authManager.getCurrentLocation();
  const permissions = user ? getUserPermissions(user.role) : null;

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeMetrics((prev) => ({
        heartRate: Math.max(
          60,
          Math.min(180, prev.heartRate + (Math.random() - 0.5) * 10),
        ),
        caloriesBurned: prev.caloriesBurned + Math.floor(Math.random() * 3),
        activeMembers: Math.max(
          0,
          Math.min(120, prev.activeMembers + (Math.random() - 0.5) * 5),
        ),
        energyLevel: Math.max(
          0,
          Math.min(100, prev.energyLevel + (Math.random() - 0.5) * 8),
        ),
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  if (!user || !currentLocation) return null;

  const isAdmin = user.role === "administrator";
  const isCoach = user.role === "coach";
  const isUser = user.role === "user";

  const adminStats = [
    {
      title: "Miembros Activos",
      value: Math.floor(realTimeMetrics.activeMembers).toString(),
      change: "+12%",
      icon: Users,
      color: "text-aurora-primary",
      bgColor: "bg-aurora-accent",
      trend: "up",
    },
    {
      title: "Ingresos Hoy",
      value: "$12,450",
      change: "+8%",
      icon: TrendingUp,
      color: "text-aurora-secondary",
      bgColor: "bg-purple-50",
      trend: "up",
    },
    {
      title: "Sesiones Activas",
      value: "24",
      change: "+15%",
      icon: Activity,
      color: "text-aurora-tertiary",
      bgColor: "bg-pink-50",
      trend: "up",
    },
    {
      title: "Satisfacción",
      value: "98%",
      change: "+2%",
      icon: Star,
      color: "text-aurora-quaternary",
      bgColor: "bg-blue-50",
      trend: "up",
    },
  ];

  const coachStats = [
    {
      title: "Clientes Hoy",
      value: "12",
      change: "+3",
      icon: Users,
      color: "text-aurora-primary",
      bgColor: "bg-aurora-accent",
      trend: "up",
    },
    {
      title: "Sesiones Completadas",
      value: "8",
      change: "+2",
      icon: Dumbbell,
      color: "text-aurora-secondary",
      bgColor: "bg-purple-50",
      trend: "up",
    },
    {
      title: "Progreso Promedio",
      value: "85%",
      change: "+5%",
      icon: TrendingUp,
      color: "text-aurora-tertiary",
      bgColor: "bg-pink-50",
      trend: "up",
    },
    {
      title: "Valoración",
      value: "4.9",
      change: "+0.1",
      icon: Star,
      color: "text-aurora-quaternary",
      bgColor: "bg-blue-50",
      trend: "up",
    },
  ];

  const userStats = [
    {
      title: "Ritmo Cardíaco",
      value: Math.floor(realTimeMetrics.heartRate).toString(),
      change: "bpm",
      icon: Heart,
      color: "text-red-500",
      bgColor: "bg-red-50",
      trend: "stable",
      realTime: true,
    },
    {
      title: "Calorías Quemadas",
      value: Math.floor(realTimeMetrics.caloriesBurned).toString(),
      change: "kcal",
      icon: Flame,
      color: "text-orange-500",
      bgColor: "bg-orange-50",
      trend: "up",
      realTime: true,
    },
    {
      title: "Nivel de Energía",
      value: `${Math.floor(realTimeMetrics.energyLevel)}%`,
      change: "óptimo",
      icon: Zap,
      color: "text-aurora-primary",
      bgColor: "bg-aurora-accent",
      trend: "up",
      realTime: true,
    },
    {
      title: "Sesiones Este Mes",
      value: "16",
      change: "+4",
      icon: Dumbbell,
      color: "text-aurora-secondary",
      bgColor: "bg-purple-50",
      trend: "up",
    },
  ];

  const stats = isAdmin ? adminStats : isCoach ? coachStats : userStats;

  const quickActions = isAdmin
    ? [
        {
          title: "Gestionar Miembros",
          icon: Users,
          color: "aurora-primary",
          action: () => navigate("/dashboard/members"),
        },
        {
          title: "Ver Reportes",
          icon: BarChart3,
          color: "aurora-secondary",
          action: () => navigate("/dashboard/reports"),
        },
        {
          title: "Gestionar Sedes",
          icon: MapPin,
          color: "aurora-tertiary",
          action: () => navigate("/dashboard/locations"),
        },
        {
          title: "Configuración",
          icon: Target,
          color: "aurora-quaternary",
          action: () => navigate("/dashboard/settings"),
        },
      ]
    : isCoach
      ? [
          {
            title: "Nueva Sesión",
            icon: Plus,
            color: "aurora-primary",
            action: () => navigate("/dashboard/training"),
          },
          {
            title: "Ver Clientes",
            icon: Users,
            color: "aurora-secondary",
            action: () => navigate("/dashboard/members"),
          },
          {
            title: "Planes Nutricionales",
            icon: Target,
            color: "aurora-tertiary",
            action: () => navigate("/dashboard/nutrition"),
          },
          {
            title: "Mi Perfil",
            icon: Activity,
            color: "aurora-quaternary",
            action: () => navigate("/dashboard/profile"),
          },
        ]
      : [
          {
            title: "Agendar Clase",
            icon: Calendar,
            color: "aurora-primary",
            action: () => navigate("/dashboard/training"),
          },
          {
            title: "Mi Rutina",
            icon: Dumbbell,
            color: "aurora-secondary",
            action: () => navigate("/dashboard/training"),
          },
          {
            title: "Mi Progreso",
            icon: TrendingUp,
            color: "aurora-tertiary",
            action: () => navigate("/dashboard/history"),
          },
          {
            title: "Nutrición",
            icon: Award,
            color: "aurora-quaternary",
            action: () => navigate("/dashboard/nutrition"),
          },
        ];

  const todaysGoals = [
    {
      title: "Sesiones de Entrenamiento",
      current: isUser ? 1 : isCoach ? 8 : 45,
      target: isUser ? 2 : isCoach ? 10 : 50,
      percentage: isUser ? 50 : isCoach ? 80 : 90,
      color: "aurora-primary",
    },
    {
      title: isUser ? "Tiempo Activo" : "Miembros Atendidos",
      current: isUser ? 45 : isCoach ? 12 : 67,
      target: isUser ? 60 : isCoach ? 15 : 80,
      percentage: isUser ? 75 : isCoach ? 80 : 84,
      color: "aurora-secondary",
    },
    {
      title: isUser ? "Calorías Objetivo" : "Planes Creados",
      current: isUser ? 1850 : isCoach ? 3 : 12,
      target: isUser ? 2200 : isCoach ? 4 : 15,
      percentage: isUser ? 84 : isCoach ? 75 : 80,
      color: "aurora-tertiary",
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome Header with Aurora Effect */}
      <div className="relative overflow-hidden rounded-2xl p-8 aurora-gradient text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2">
                ¡Hola, {user.name}! ✨
              </h1>
              <p className="text-white/90 text-lg">
                Bienvenido a {currentLocation.name} - Tu transformación continúa
              </p>
              <div className="mt-4 flex items-center gap-4">
                <Badge className="bg-white/20 text-white hover:bg-white/30 px-4 py-2">
                  {new Date().toLocaleDateString("es-ES", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                  })}
                </Badge>
                {isUser && (
                  <Badge className="bg-white/20 text-white hover:bg-white/30 px-4 py-2">
                    🔥 Racha: 7 días
                  </Badge>
                )}
              </div>
            </div>
            <div className="hidden md:block">
              <Button
                className="w-32 h-32 rounded-full bg-white/10 hover:bg-white/20 border-2 border-white/20 hover:border-white/30 transition-all duration-300"
                onClick={() =>
                  navigate(
                    isAdmin
                      ? "/dashboard/members"
                      : isCoach
                        ? "/dashboard/training"
                        : "/dashboard/training",
                  )
                }
              >
                <Dumbbell className="h-16 w-16 text-white" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card
              key={index}
              className="aurora-card-glow hover:scale-105 transition-all duration-300"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                    <Icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                  {stat.realTime && (
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-600 font-medium">
                        LIVE
                      </span>
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">
                    {stat.title}
                  </p>
                  <div className="flex items-baseline gap-2">
                    <p className="text-3xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                    <p
                      className={`text-sm font-medium ${
                        stat.trend === "up"
                          ? "text-green-600"
                          : stat.trend === "down"
                            ? "text-red-600"
                            : "text-gray-600"
                      }`}
                    >
                      {stat.change}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Today's Goals */}
        <div className="lg:col-span-2">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Target className="h-6 w-6 text-aurora-primary" />
                Objetivos de Hoy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {todaysGoals.map((goal, index) => (
                <div key={index} className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900">
                      {goal.title}
                    </span>
                    <span className="text-sm text-gray-600">
                      {goal.current} / {goal.target}
                    </span>
                  </div>
                  <div className="relative">
                    <Progress
                      value={goal.percentage}
                      className="h-3"
                      style={{
                        background: `hsl(var(--${goal.color}) / 0.2)`,
                      }}
                    />
                    <div
                      className="absolute inset-y-0 left-0 rounded-full transition-all duration-1000"
                      style={{
                        width: `${goal.percentage}%`,
                        background: `linear-gradient(90deg, hsl(var(--${goal.color})), hsl(var(--${goal.color}) / 0.8))`,
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle>Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`w-full justify-start gap-3 h-12 hover:bg-${action.color}/10 hover:text-${action.color} transition-all duration-300`}
                    onClick={action.action}
                  >
                    <Icon className="h-5 w-5" />
                    {action.title}
                  </Button>
                );
              })}
            </CardContent>
          </Card>

          {/* Achievement Spotlight */}
          <Card className="aurora-card bg-gradient-to-br from-aurora-accent to-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-aurora-primary" />
                Logro Destacado
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-4">
                <div className="text-4xl mb-2">🏆</div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  {isUser
                    ? "¡Semana Perfecta!"
                    : isCoach
                      ? "¡Coach del Mes!"
                      : "¡Crecimiento Récord!"}
                </h3>
                <p className="text-sm text-gray-600">
                  {isUser
                    ? "Completaste todas tus sesiones esta semana"
                    : isCoach
                      ? "Excelente calificación de tus clientes"
                      : "40% más miembros este mes"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Enhanced Features Section */}
      <Tabs defaultValue="insights" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="insights">Insights IA</TabsTrigger>
          <TabsTrigger value="community">Comunidad</TabsTrigger>
          <TabsTrigger value="challenges">Desafíos</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-aurora-primary" />
                Recomendaciones Personalizadas IA
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  title: "Momento Óptimo de Entrenamiento",
                  description:
                    "Basado en tu ritmo cardíaco, las 6:00 PM es tu mejor hora",
                  confidence: 92,
                  icon: "⚡",
                },
                {
                  title: "Hidratación",
                  description:
                    "Aumenta tu consumo de agua en un 15% para mejor rendimiento",
                  confidence: 87,
                  icon: "💧",
                },
                {
                  title: "Descanso",
                  description: "Considera un día de recuperación activa mañana",
                  confidence: 95,
                  icon: "😴",
                },
              ].map((insight, index) => (
                <div
                  key={index}
                  className="flex items-start gap-4 p-4 rounded-xl bg-aurora-accent/30 hover:bg-aurora-accent/50 transition-colors"
                >
                  <span className="text-2xl">{insight.icon}</span>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">
                      {insight.title}
                    </h4>
                    <p className="text-sm text-gray-600 mb-2">
                      {insight.description}
                    </p>
                    <div className="flex items-center gap-2">
                      <Progress
                        value={insight.confidence}
                        className="h-1 flex-1"
                      />
                      <span className="text-xs text-gray-500">
                        {insight.confidence}% confianza
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="community" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-aurora-primary" />
                Actividad de la Comunidad
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    user: "María G.",
                    action: "completó un entrenamiento de fuerza",
                    time: "hace 5 min",
                    badge: "🔥",
                  },
                  {
                    user: "Carlos R.",
                    action: "alcanzó su meta de 10,000 pasos",
                    time: "hace 15 min",
                    badge: "🏃‍♂️",
                  },
                  {
                    user: "Ana L.",
                    action: "inició el desafío de 30 días",
                    time: "hace 1 hora",
                    badge: "💪",
                  },
                ].map((activity, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <span className="text-lg">{activity.badge}</span>
                    <div className="flex-1">
                      <p className="text-sm">
                        <span className="font-medium">{activity.user}</span>{" "}
                        {activity.action}
                      </p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="challenges" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-aurora-primary" />
                Desafíos Activos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  title: "Desafío Aurora de 30 Días",
                  description: "Entrena 30 días consecutivos",
                  progress: 23,
                  total: 30,
                  reward: "Medal de Constancia",
                  participants: 156,
                },
                {
                  title: "Quema 10,000 Calorías",
                  description: "Meta mensual de calorías",
                  progress: 7350,
                  total: 10000,
                  reward: "Badge de Fuego",
                  participants: 89,
                },
              ].map((challenge, index) => (
                <div
                  key={index}
                  className="p-4 rounded-xl aurora-gradient text-white"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold">{challenge.title}</h4>
                    <Badge className="bg-white/20 text-white">
                      {challenge.participants} participantes
                    </Badge>
                  </div>
                  <p className="text-white/90 text-sm mb-3">
                    {challenge.description}
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>
                        {challenge.progress} / {challenge.total}
                      </span>
                      <span>
                        {Math.round(
                          (challenge.progress / challenge.total) * 100,
                        )}
                        %
                      </span>
                    </div>
                    <Progress
                      value={(challenge.progress / challenge.total) * 100}
                      className="bg-white/20"
                    />
                    <p className="text-xs text-white/80">
                      🏆 Recompensa: {challenge.reward}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DashboardHome;
