import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Users,
  DollarSign,
  Activity,
  Calendar as CalendarIcon,
  Download,
  Filter,
  Eye,
  Clock,
  Target,
  Award,
  Zap,
  AlertTriangle,
} from "lucide-react";
import { authManager } from "@/lib/auth";
import { format } from "date-fns";
import { es } from "date-fns/locale";

const Reports = () => {
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined;
    to: Date | undefined;
  }>({
    from: new Date(2024, 0, 1),
    to: new Date(),
  });
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  const user = authManager.getCurrentUser();

  if (!user || user.role !== "administrator") {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Acceso Restringido</h2>
          <p className="text-gray-600">
            Solo los administradores pueden ver los reportes.
          </p>
        </div>
      </div>
    );
  }

  // Mock data for reports
  const revenueData = {
    current: 125800,
    previous: 118400,
    growth: 6.2,
    target: 150000,
    monthlyBreakdown: [
      { month: "Ene", revenue: 98000, members: 180 },
      { month: "Feb", revenue: 105000, members: 195 },
      { month: "Mar", revenue: 115000, members: 210 },
      { month: "Abr", revenue: 118000, members: 225 },
      { month: "May", revenue: 125800, members: 234 },
    ],
  };

  const membershipData = {
    total: 234,
    new: 28,
    renewals: 198,
    cancellations: 8,
    retention: 89.5,
    breakdown: {
      basic: { count: 89, revenue: 71200, percentage: 38 },
      premium: { count: 118, revenue: 141600, percentage: 50 },
      vip: { count: 27, revenue: 54000, percentage: 12 },
    },
  };

  const performanceMetrics = {
    avgSessionsPerMember: 12.5,
    peakHours: "18:00 - 20:00",
    avgSessionDuration: 65,
    memberSatisfaction: 4.7,
    coachRating: 4.8,
    equipmentUsage: 78,
  };

  const topPerformers = [
    {
      name: "María González",
      role: "Coach",
      metric: "Satisfacción",
      value: "4.9/5.0",
      sessions: 156,
    },
    {
      name: "Roberto Silva",
      role: "Coach",
      metric: "Sesiones",
      value: "142",
      satisfaction: "4.8/5.0",
    },
    {
      name: "Ana García",
      role: "Miembro",
      metric: "Asistencia",
      value: "96%",
      sessions: 45,
    },
    {
      name: "Carlos Mendoza",
      role: "Miembro",
      metric: "Progreso",
      value: "+15kg",
      improvement: "85%",
    },
  ];

  const alerts = [
    {
      type: "revenue",
      message: "Ingresos 15% por debajo del objetivo mensual",
      severity: "warning",
      action: "Revisar estrategia de retención",
    },
    {
      type: "equipment",
      message: "Equipo de cardio necesita mantenimiento",
      severity: "high",
      action: "Programar mantenimiento urgente",
    },
    {
      type: "staff",
      message: "Coach María González superó 150 sesiones este mes",
      severity: "success",
      action: "Considerar bonificación",
    },
    {
      type: "members",
      message: "5 miembros con pagos vencidos >30 días",
      severity: "high",
      action: "Contactar para renovación",
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold aurora-text-gradient flex items-center gap-3">
            <BarChart3 className="h-8 w-8 text-aurora-primary" />
            Reportes y Análisis
          </h1>
          <p className="text-gray-600 mt-1 text-lg">
            Análisis completo del rendimiento y métricas del gimnasio
          </p>
        </div>
        <div className="flex gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Esta semana</SelectItem>
              <SelectItem value="month">Este mes</SelectItem>
              <SelectItem value="quarter">Este trimestre</SelectItem>
              <SelectItem value="year">Este año</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar PDF
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="aurora-card-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ingresos Totales</p>
                <p className="text-3xl font-bold text-aurora-primary">
                  ${revenueData.current.toLocaleString()}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-600 font-medium">
                    +{revenueData.growth}%
                  </span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-aurora-accent">
                <DollarSign className="h-6 w-6 text-aurora-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="aurora-card-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Miembros Activos</p>
                <p className="text-3xl font-bold text-aurora-secondary">
                  {membershipData.total}
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-600 font-medium">
                    +{membershipData.new} nuevos
                  </span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-purple-50">
                <Users className="h-6 w-6 text-aurora-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="aurora-card-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Retención</p>
                <p className="text-3xl font-bold text-aurora-tertiary">
                  {membershipData.retention}%
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-600 font-medium">
                    +2.3% vs mes anterior
                  </span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-pink-50">
                <Target className="h-6 w-6 text-aurora-tertiary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="aurora-card-glow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Satisfacción</p>
                <p className="text-3xl font-bold text-aurora-quaternary">
                  {performanceMetrics.memberSatisfaction}/5.0
                </p>
                <div className="flex items-center gap-1 mt-1">
                  <Award className="h-4 w-4 text-yellow-600" />
                  <span className="text-sm text-yellow-600 font-medium">
                    Excelente
                  </span>
                </div>
              </div>
              <div className="p-3 rounded-xl bg-blue-50">
                <Award className="h-6 w-6 text-aurora-quaternary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Progress */}
      <Card className="aurora-card">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Progreso hacia Objetivo Mensual</span>
            <span className="text-sm text-gray-600">
              ${revenueData.current.toLocaleString()} / $
              {revenueData.target.toLocaleString()}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Progress
              value={(revenueData.current / revenueData.target) * 100}
              className="h-4"
            />
            <div className="flex justify-between text-sm text-gray-600">
              <span>
                {Math.round((revenueData.current / revenueData.target) * 100)}%
                completado
              </span>
              <span>
                ${(revenueData.target - revenueData.current).toLocaleString()}{" "}
                restante
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="revenue" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="revenue">Ingresos</TabsTrigger>
          <TabsTrigger value="members">Miembros</TabsTrigger>
          <TabsTrigger value="performance">Rendimiento</TabsTrigger>
          <TabsTrigger value="staff">Personal</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
        </TabsList>

        {/* Revenue Analysis */}
        <TabsContent value="revenue" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Ingresos por Mes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {revenueData.monthlyBreakdown.map((month, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between"
                    >
                      <span className="font-medium">{month.month}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-sm text-gray-600">
                          {month.members} miembros
                        </span>
                        <span className="font-bold text-aurora-primary">
                          ${month.revenue.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Ingresos por Tipo de Membresía</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-blue-100 text-blue-800">
                        Básico
                      </Badge>
                      <span>
                        {membershipData.breakdown.basic.count} miembros
                      </span>
                    </div>
                    <span className="font-bold">
                      ${membershipData.breakdown.basic.revenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="bg-aurora-accent text-aurora-primary">
                        Premium
                      </Badge>
                      <span>
                        {membershipData.breakdown.premium.count} miembros
                      </span>
                    </div>
                    <span className="font-bold">
                      $
                      {membershipData.breakdown.premium.revenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge className="aurora-gradient text-white">VIP</Badge>
                      <span>{membershipData.breakdown.vip.count} miembros</span>
                    </div>
                    <span className="font-bold">
                      ${membershipData.breakdown.vip.revenue.toLocaleString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Members Analysis */}
        <TabsContent value="members" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Nuevos Miembros</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-4xl font-bold text-aurora-primary mb-2">
                    {membershipData.new}
                  </p>
                  <p className="text-gray-600">Este mes</p>
                  <Badge className="bg-green-100 text-green-800 mt-2">
                    +40% vs mes anterior
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Renovaciones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-4xl font-bold text-aurora-secondary mb-2">
                    {membershipData.renewals}
                  </p>
                  <p className="text-gray-600">Este mes</p>
                  <Badge className="bg-blue-100 text-blue-800 mt-2">
                    89% tasa de renovación
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Cancelaciones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <p className="text-4xl font-bold text-red-600 mb-2">
                    {membershipData.cancellations}
                  </p>
                  <p className="text-gray-600">Este mes</p>
                  <Badge className="bg-red-100 text-red-800 mt-2">
                    3.4% del total
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Performance Metrics */}
        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Métricas de Uso</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Sesiones promedio por miembro</span>
                  <span className="font-bold text-aurora-primary">
                    {performanceMetrics.avgSessionsPerMember}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Duración promedio de sesión</span>
                  <span className="font-bold text-aurora-secondary">
                    {performanceMetrics.avgSessionDuration} min
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Horas pico</span>
                  <span className="font-bold text-aurora-tertiary">
                    {performanceMetrics.peakHours}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Uso de equipos</span>
                  <span className="font-bold text-aurora-quaternary">
                    {performanceMetrics.equipmentUsage}%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="aurora-card">
              <CardHeader>
                <CardTitle>Calificaciones</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Satisfacción de miembros</span>
                    <span className="font-bold">
                      {performanceMetrics.memberSatisfaction}/5.0
                    </span>
                  </div>
                  <Progress
                    value={(performanceMetrics.memberSatisfaction / 5) * 100}
                    className="h-2"
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Calificación de coaches</span>
                    <span className="font-bold">
                      {performanceMetrics.coachRating}/5.0
                    </span>
                  </div>
                  <Progress
                    value={(performanceMetrics.coachRating / 5) * 100}
                    className="h-2"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Staff Performance */}
        <TabsContent value="staff" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle>Top Performers Este Mes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topPerformers.map((performer, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-aurora-accent/20 hover:bg-aurora-accent/30 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-aurora-gradient flex items-center justify-center text-white font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <h4 className="font-semibold">{performer.name}</h4>
                        <p className="text-sm text-gray-600">
                          {performer.role}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-aurora-primary">
                        {performer.metric}: {performer.value}
                      </p>
                      <p className="text-sm text-gray-600">
                        {performer.sessions
                          ? `${performer.sessions} sesiones`
                          : performer.satisfaction ||
                            performer.improvement ||
                            ""}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Alerts */}
        <TabsContent value="alerts" className="space-y-6">
          <Card className="aurora-card">
            <CardHeader>
              <CardTitle>Alertas y Notificaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.map((alert, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-xl border-l-4 ${
                      alert.severity === "high"
                        ? "bg-red-50 border-red-500"
                        : alert.severity === "warning"
                          ? "bg-yellow-50 border-yellow-500"
                          : "bg-green-50 border-green-500"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {alert.severity === "high" && (
                            <AlertTriangle className="h-5 w-5 text-red-600" />
                          )}
                          {alert.severity === "warning" && (
                            <Clock className="h-5 w-5 text-yellow-600" />
                          )}
                          {alert.severity === "success" && (
                            <Zap className="h-5 w-5 text-green-600" />
                          )}
                          <Badge
                            className={
                              alert.severity === "high"
                                ? "bg-red-100 text-red-800"
                                : alert.severity === "warning"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-green-100 text-green-800"
                            }
                          >
                            {alert.severity === "high"
                              ? "Urgente"
                              : alert.severity === "warning"
                                ? "Atención"
                                : "Buenas noticias"}
                          </Badge>
                        </div>
                        <p className="font-medium mb-1">{alert.message}</p>
                        <p className="text-sm text-gray-600">
                          Acción recomendada: {alert.action}
                        </p>
                      </div>
                      <Button size="sm" variant="outline">
                        <Eye className="h-4 w-4 mr-2" />
                        Ver
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;
