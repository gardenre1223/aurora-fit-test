import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Dumbbell, Eye, EyeOff, Sparkles } from "lucide-react";
import { authManager } from "@/lib/auth";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      await authManager.login(email, password);
      navigate("/location-selection");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error al iniciar sesión");
    } finally {
      setIsLoading(false);
    }
  };

  const demoCredentials = [
    {
      role: "Administrador",
      email: "admin@aurorafit.com",
      password: "admin123",
      description: "Control total",
      icon: "⚡",
      color: "from-violet-500 to-purple-600",
    },
    {
      role: "Coach",
      email: "coach@aurorafit.com",
      password: "coach123",
      description: "Entrena clientes",
      icon: "🏃‍♂️",
      color: "from-emerald-500 to-teal-600",
    },
    {
      role: "Usuario",
      email: "user@aurorafit.com",
      password: "user123",
      description: "Entrena y mejora",
      icon: "💪",
      color: "from-orange-500 to-red-600",
    },
  ];

  const fillDemoCredentials = (email: string, password: string) => {
    setEmail(email);
    setPassword(password);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center p-4">
      {/* Floating background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-20 h-20 bg-aurora-primary/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-aurora-secondary/20 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-aurora-tertiary/20 rounded-full blur-xl animate-pulse delay-2000"></div>
        <div className="absolute bottom-40 right-10 w-12 h-12 bg-aurora-quaternary/20 rounded-full blur-xl animate-pulse delay-3000"></div>
      </div>

      <div className="w-full max-w-4xl relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Left side - Branding */}
          <div className="text-center lg:text-left space-y-6 animate-fade-in">
            <div className="flex items-center justify-center lg:justify-start mb-6">
              <div className="relative">
                <div className="p-4 aurora-gradient rounded-2xl shadow-xl">
                  <Dumbbell className="h-10 w-10 text-white" />
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                  <Sparkles className="h-3 w-3 text-yellow-800" />
                </div>
              </div>
            </div>

            <div>
              <h1 className="text-5xl lg:text-6xl font-bold aurora-text-gradient mb-4 tracking-tight">
                AuroraFit
              </h1>
              <p className="text-xl text-gray-600 mb-6 leading-relaxed">
                Transforma tu bienestar con entrenamientos personalizados
              </p>
            </div>

            {/* Features showcase */}
            <div className="hidden lg:block space-y-4">
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-8 h-8 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                  ✓
                </div>
                <span>Planes personalizados con IA</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                  ✓
                </div>
                <span>Seguimiento en tiempo real</span>
              </div>
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                  ✓
                </div>
                <span>+1000 ejercicios disponibles</span>
              </div>
            </div>
          </div>

          {/* Right side - Login form */}
          <div className="space-y-6 animate-fade-in delay-200">
            {/* Main login card */}
            <Card className="backdrop-blur-md bg-white/90 border border-white/20 shadow-2xl">
              <CardHeader className="text-center space-y-2 pb-6">
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Iniciar Sesión
                </CardTitle>
                <p className="text-gray-600">
                  Accede a tu transformación personal
                </p>
              </CardHeader>

              <CardContent className="space-y-5">
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <Alert
                      variant="destructive"
                      className="animate-fade-in border-red-200 bg-red-50"
                    >
                      <AlertDescription className="text-red-800">
                        {error}
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="space-y-2">
                    <Label
                      htmlFor="email"
                      className="text-sm font-medium text-gray-700"
                    >
                      Correo Electrónico
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="correo@ejemplo.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="h-11 border-gray-200 focus:border-aurora-primary focus:ring-aurora-primary/20"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label
                      htmlFor="password"
                      className="text-sm font-medium text-gray-700"
                    >
                      Contraseña
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Ingresa tu contraseña"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="h-11 pr-10 border-gray-200 focus:border-aurora-primary focus:ring-aurora-primary/20"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-11 aurora-gradient text-white font-medium shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-300"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Iniciando sesión...
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Iniciar Sesión
                      </>
                    )}
                  </Button>
                </form>

                {/* Divider */}
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-200" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="bg-white px-3 text-gray-500 font-medium">
                      Cuentas demo
                    </span>
                  </div>
                </div>

                {/* Demo credentials */}
                <div className="space-y-3">
                  {demoCredentials.map((cred, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className={`w-full h-auto p-3 border-0 bg-gradient-to-r ${cred.color} text-white hover:scale-[1.02] transition-all duration-300 shadow-md hover:shadow-lg`}
                      onClick={() =>
                        fillDemoCredentials(cred.email, cred.password)
                      }
                    >
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{cred.icon}</span>
                          <div className="text-left">
                            <p className="font-semibold text-sm">{cred.role}</p>
                            <p className="text-white/80 text-xs">
                              {cred.description}
                            </p>
                          </div>
                        </div>
                        <svg
                          className="w-4 h-4 opacity-70"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </div>
                    </Button>
                  ))}
                </div>

                {/* Footer */}
                <div className="text-center pt-4">
                  <p className="text-sm text-gray-500">
                    ¿Primera vez?{" "}
                    <span className="text-aurora-primary font-medium cursor-pointer hover:underline">
                      Solicita tu prueba gratuita
                    </span>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
