import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bot,
  Send,
  Minimize2,
  Maximize2,
  Sparkles,
  Brain,
  MessageCircle,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { authManager } from "@/lib/auth";

interface Message {
  id: string;
  content: string;
  isAI: boolean;
  timestamp: Date;
  suggestions?: string[];
}

interface AIAssistantProps {
  className?: string;
  defaultMinimized?: boolean;
}

export function AIAssistant({
  className,
  defaultMinimized = false,
}: AIAssistantProps) {
  const [isMinimized, setIsMinimized] = useState(defaultMinimized);
  const [isVisible, setIsVisible] = useState(true);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content:
        "¡Hola! Soy Aurora, tu asistente de IA personal. Estoy aquí para ayudarte con entrenamientos, nutrición y bienestar. ¿En qué puedo ayudarte hoy?",
      isAI: true,
      timestamp: new Date(),
      suggestions: [
        "Crear rutina personalizada",
        "Análisis nutricional",
        "Consejos de recuperación",
        "Motivación diaria",
      ],
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const user = authManager.getCurrentUser();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: message,
      isAI: false,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(message, user?.role);
      setMessages((prev) => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const generateAIResponse = (
    userMessage: string,
    userRole?: string,
  ): Message => {
    const message = userMessage.toLowerCase();

    let response = "";
    let suggestions: string[] = [];

    if (
      message.includes("rutina") ||
      message.includes("ejercicio") ||
      message.includes("entrenamiento")
    ) {
      response =
        userRole === "user"
          ? "🏋️‍♀️ Te recomiendo una rutina personalizada basada en tu nivel actual. Considerando tu progreso, sugiero: 3 días de fuerza + 2 días cardio. ¿Te gustaría que ajuste la intensidad?"
          : "Como coach, puedo ayudarte a crear rutinas específicas para tus clientes. ¿Qué tipo de entrenamiento necesitas diseñar?";
      suggestions = [
        "Rutina para principiantes",
        "Entrenamiento de fuerza",
        "Cardio HIIT",
        "Yoga y flexibilidad",
      ];
    } else if (
      message.includes("nutrición") ||
      message.includes("comida") ||
      message.includes("dieta")
    ) {
      response =
        "🥗 Para optimizar tu nutrición, analizo que necesitas aumentar la proteína en un 15%. Te sugiero: desayuno rico en proteínas, snacks balanceados y cena ligera. ¿Tienes alguna restricción alimentaria?";
      suggestions = [
        "Plan de pérdida de peso",
        "Ganar masa muscular",
        "Dieta vegetariana",
        "Meal prep semanal",
      ];
    } else if (message.includes("motivación") || message.includes("ánimo")) {
      response =
        "✨ ¡Recuerda por qué empezaste! Cada día que entrenas te acercas más a tu mejor versión. Tu progreso del 78% es excepcional. ¡Sigue así, campeón!";
      suggestions = [
        "Establecer nueva meta",
        "Ver mi progreso",
        "Frases motivacionales",
        "Celebrar logros",
      ];
    } else if (
      message.includes("dolor") ||
      message.includes("lesión") ||
      message.includes("recuperación")
    ) {
      response =
        "🩺 La recuperación es clave. Te recomiendo: descanso activo hoy, estiramientos suaves, hidratación extra y sueño de calidad. Si persiste el dolor, consulta con un profesional.";
      suggestions = [
        "Rutina de recuperación",
        "Ejercicios de movilidad",
        "Tips de sueño",
        "Cuándo descansar",
      ];
    } else {
      response =
        "🤖 Entiendo tu consulta. Como tu asistente personal, puedo ayudarte con rutinas, nutrición, motivación y seguimiento de progreso. ¿Sobre qué tema específico te gustaría que conversemos?";
      suggestions = [
        "Entrenamientos",
        "Nutrición",
        "Progreso",
        "Bienestar general",
      ];
    }

    return {
      id: Date.now().toString(),
      content: response,
      isAI: true,
      timestamp: new Date(),
      suggestions,
    };
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  if (!isVisible) return null;

  return (
    <Card
      className={cn(
        "fixed bottom-4 right-4 z-50 w-80 aurora-card-glow transition-all duration-300",
        isMinimized ? "h-16" : "h-96",
        className,
      )}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm">
            <div className="relative">
              <Bot className="h-5 w-5 text-aurora-primary" />
              <Sparkles className="h-3 w-3 text-aurora-tertiary absolute -top-1 -right-1 animate-pulse" />
            </div>
            <span className="aurora-text-gradient font-semibold">
              Aurora AI
            </span>
            <Badge className="bg-aurora-accent text-aurora-primary text-xs px-2 py-0">
              Online
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setIsMinimized(!isMinimized)}
            >
              {isMinimized ? (
                <Maximize2 className="h-3 w-3" />
              ) : (
                <Minimize2 className="h-3 w-3" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setIsVisible(false)}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardHeader>

      {!isMinimized && (
        <CardContent className="p-4 pt-0 flex flex-col h-80">
          {/* Messages */}
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className="space-y-2">
                  <div
                    className={cn(
                      "flex",
                      message.isAI ? "justify-start" : "justify-end",
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-xs rounded-xl px-3 py-2 text-sm",
                        message.isAI
                          ? "bg-aurora-accent text-gray-800"
                          : "aurora-gradient text-white",
                      )}
                    >
                      {message.isAI && (
                        <div className="flex items-center gap-1 mb-1">
                          <Brain className="h-3 w-3" />
                          <span className="text-xs font-medium">Aurora</span>
                        </div>
                      )}
                      <p>{message.content}</p>
                    </div>
                  </div>

                  {/* Suggestions */}
                  {message.suggestions && (
                    <div className="flex flex-wrap gap-1 ml-2">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs h-6 px-2 hover:bg-aurora-accent hover:border-aurora-primary"
                          onClick={() => handleSuggestionClick(suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {/* Typing indicator */}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-aurora-accent rounded-xl px-3 py-2">
                    <div className="flex items-center gap-1">
                      <Brain className="h-3 w-3 text-aurora-primary" />
                      <div className="flex gap-1">
                        <div className="w-1 h-1 bg-aurora-primary rounded-full animate-bounce"></div>
                        <div
                          className="w-1 h-1 bg-aurora-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-1 h-1 bg-aurora-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div ref={messagesEndRef} />
          </ScrollArea>

          {/* Input */}
          <div className="flex gap-2 mt-3">
            <Input
              placeholder="Pregúntame algo..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  handleSendMessage(inputMessage);
                }
              }}
              className="flex-1 h-8 text-sm"
            />
            <Button
              size="sm"
              className="aurora-button-primary h-8 w-8 p-0"
              onClick={() => handleSendMessage(inputMessage)}
              disabled={!inputMessage.trim()}
            >
              <Send className="h-3 w-3" />
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

// Floating activation button when assistant is hidden
export function AIAssistantTrigger() {
  const [showAssistant, setShowAssistant] = useState(false);

  if (showAssistant) {
    return <AIAssistant />;
  }

  return (
    <Button
      className="fixed bottom-4 right-4 z-50 h-14 w-14 rounded-full aurora-gradient shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
      onClick={() => setShowAssistant(true)}
    >
      <div className="relative">
        <MessageCircle className="h-6 w-6 text-white" />
        <Sparkles className="h-4 w-4 text-white absolute -top-1 -right-1 animate-pulse" />
      </div>
    </Button>
  );
}
