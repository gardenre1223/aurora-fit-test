import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Home,
  Dumbbell,
  Apple,
  User,
  Users,
  History,
  Settings,
  Lightbulb,
  LogOut,
  Menu,
  Building2,
  ChevronDown,
} from "lucide-react";
import { authManager, getUserPermissions } from "@/lib/auth";

const getNavigation = (userRole: string) => {
  const baseNavigation = [
    { name: "Inicio", href: "/dashboard", icon: Home },
    { name: "Entrenamientos", href: "/dashboard/training", icon: Dumbbell },
    { name: "Ejercicios", href: "/dashboard/exercises", icon: Lightbulb },
    { name: "Nutrición", href: "/dashboard/nutrition", icon: Apple },
    { name: "Perfil", href: "/dashboard/profile", icon: User },
    { name: "Historial", href: "/dashboard/history", icon: History },
    { name: "Configuración", href: "/dashboard/settings", icon: Settings },
  ];

  // Add admin-only navigation items
  if (userRole === "administrator") {
    baseNavigation.splice(4, 0, {
      name: "Miembros",
      href: "/dashboard/members",
      icon: Users,
    });
    baseNavigation.splice(5, 0, {
      name: "Sedes",
      href: "/dashboard/locations",
      icon: Building2,
    });
  }

  return baseNavigation;
};

interface DashboardNavProps {
  children: React.ReactNode;
}

export function DashboardNav({ children }: DashboardNavProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const user = authManager.getCurrentUser();
  const currentLocation = authManager.getCurrentLocation();
  const permissions = user ? getUserPermissions(user.role) : null;

  if (!user || !currentLocation) {
    navigate("/login");
    return null;
  }

  const handleLogout = () => {
    authManager.logout();
    navigate("/login");
  };

  const handleLocationChange = () => {
    navigate("/location-selection");
  };

  const NavLink = ({
    item,
    isMobile = false,
  }: {
    item: (typeof navigation)[0];
    isMobile?: boolean;
  }) => {
    const isActive = location.pathname === item.href;
    const Icon = item.icon;

    return (
      <Button
        variant={isActive ? "secondary" : "ghost"}
        className={cn(
          "w-full justify-start gap-3 h-11 transition-all duration-300",
          isActive &&
            "bg-aurora-accent text-aurora-primary font-medium shadow-sm",
          isMobile && "text-base py-3 h-auto",
        )}
        onClick={() => {
          navigate(item.href);
          if (isMobile) setIsMobileMenuOpen(false);
        }}
      >
        <Icon className="h-5 w-5" />
        {item.name}
      </Button>
    );
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case "administrator":
        return "Administrador";
      case "coach":
        return "Coach";
      case "user":
        return "Usuario";
      default:
        return role;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
        <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white border-r border-gray-200 px-6 pb-4">
          {/* Logo */}
          <div className="flex h-16 shrink-0 items-center gap-3">
            <div className="p-2 aurora-gradient rounded-xl shadow-lg">
              <Dumbbell className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold aurora-text-gradient">
                AuroraFit
              </h1>
              <p className="text-xs text-gray-600">Transforma tu bienestar</p>
            </div>
          </div>

          {/* Current Location */}
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-between h-auto py-3 hover:bg-aurora-accent hover:border-aurora-primary transition-all duration-300"
              onClick={handleLocationChange}
            >
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-aurora-primary" />
                <div className="text-left">
                  <p className="font-medium text-sm">{currentLocation.name}</p>
                  <p className="text-xs text-gray-600">
                    {currentLocation.city}
                  </p>
                </div>
              </div>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>

          {/* Navigation */}
          <nav className="flex flex-1 flex-col">
            <ul role="list" className="flex flex-1 flex-col gap-y-2">
              {getNavigation(user.role).map((item) => (
                <li key={item.name}>
                  <NavLink item={item} />
                </li>
              ))}
              <li className="mt-auto">
                <div className="pt-4 border-t border-gray-200">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full justify-start gap-3 h-auto py-3"
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback className="bg-gym-primary text-white text-sm">
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="text-left flex-1">
                          <p className="font-medium text-sm">{user.name}</p>
                          <Badge
                            variant="secondary"
                            className="text-xs bg-aurora-accent text-aurora-primary"
                          >
                            {getRoleLabel(user.role)}
                          </Badge>
                        </div>
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="w-56">
                      <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => navigate("/dashboard/profile")}
                      >
                        <User className="mr-2 h-4 w-4" />
                        Perfil
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => navigate("/dashboard/settings")}
                      >
                        <Settings className="mr-2 h-4 w-4" />
                        Configuración
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLocationChange}>
                        <Building2 className="mr-2 h-4 w-4" />
                        Cambiar Sede
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={handleLogout}
                        className="text-red-600"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        Cerrar Sesión
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="sticky top-0 z-40 flex h-16 shrink-0 items-center gap-x-4 border-b border-gray-200 bg-white px-4 shadow-sm sm:gap-x-6 sm:px-6 lg:hidden">
        <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="-m-2.5 p-2.5">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Abrir menú</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-72">
            <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white px-6 pb-4">
              {/* Mobile Logo */}
              <div className="flex h-16 shrink-0 items-center gap-3">
                <div className="p-2 aurora-gradient rounded-xl shadow-lg">
                  <Dumbbell className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold aurora-text-gradient">
                    AuroraFit
                  </h1>
                  <p className="text-xs text-gray-600">
                    Transforma tu bienestar
                  </p>
                </div>
              </div>

              {/* Mobile Navigation */}
              <nav className="flex flex-1 flex-col gap-y-2">
                {getNavigation(user.role).map((item) => (
                  <NavLink key={item.name} item={item} isMobile />
                ))}
              </nav>
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex flex-1 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 aurora-gradient rounded-lg shadow-md">
              <Dumbbell className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-lg font-bold aurora-text-gradient">
              AuroraFit
            </h1>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="bg-gym-primary text-white text-sm">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div>
                  <p className="font-medium">{user.name}</p>
                  <p className="text-sm text-gray-600">{user.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("/dashboard/profile")}>
                <User className="mr-2 h-4 w-4" />
                Perfil
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLocationChange}>
                <Building2 className="mr-2 h-4 w-4" />
                Cambiar Sede
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                <LogOut className="mr-2 h-4 w-4" />
                Cerrar Sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:pl-72">
        <main className="py-6 px-4 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
