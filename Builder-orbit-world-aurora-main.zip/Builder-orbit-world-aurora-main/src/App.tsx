import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import LocationSelection from "./pages/LocationSelection";
import Dashboard from "./pages/Dashboard";
import DashboardHome from "./pages/DashboardHome";
import Training from "./pages/Training";
import Nutrition from "./pages/Nutrition";
import Profile from "./pages/Profile";
import History from "./pages/History";
import Settings from "./pages/Settings";
import MemberManagement from "./pages/MemberManagement";
import Reports from "./pages/Reports";
import ExerciseRecommendations from "./pages/ExerciseRecommendations";
import LocationManagement from "./pages/LocationManagement";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Redirect root to login */}
          <Route path="/" element={<Navigate to="/login" replace />} />

          {/* Authentication routes */}
          <Route path="/login" element={<Login />} />
          <Route path="/location-selection" element={<LocationSelection />} />

          {/* Dashboard routes */}
          <Route path="/dashboard" element={<Dashboard />}>
            <Route index element={<DashboardHome />} />
            <Route path="training" element={<Training />} />
            <Route path="nutrition" element={<Nutrition />} />
            <Route path="profile" element={<Profile />} />
            <Route path="history" element={<History />} />
            <Route path="settings" element={<Settings />} />
            <Route path="members" element={<MemberManagement />} />
            <Route path="reports" element={<Reports />} />
            <Route path="exercises" element={<ExerciseRecommendations />} />
            <Route path="locations" element={<LocationManagement />} />
          </Route>

          {/* Catch-all route for 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
