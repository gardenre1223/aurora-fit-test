# 🏋️‍♀️ AuroraFit - Sistema de Gestión de Gimnasios

<p align="center">
  <img src="public/assets/logos/aurorafit-logo.svg" alt="AuroraFit Logo" width="200" height="80">
</p>

<p align="center">
  <em>Sistema integral de gestión para gimnasios con diseño inspirado en la aurora boreal</em>
</p>

<p align="center">
  <a href="#características">Características</a> •
  <a href="#instalación">Instalación</a> •
  <a href="#uso">Uso</a> •
  <a href="#estructura">Estructura</a> •
  <a href="#tecnologías">Tecnologías</a>
</p>

---

## 📖 Descripción

AuroraFit es una aplicación web moderna para la gestión integral de gimnasios, diseñada con una estética inspirada en la aurora boreal. El sistema permite administrar miembros, entrenamientos, nutrición, ubicaciones y reportes de manera eficiente y atractiva.

## ✨ Características

### 🔐 **Sistema de Autenticación Multi-Rol**

- **Administrador**: Acceso completo al sistema
- **Coach**: Gestión de entrenamientos y clientes
- **Usuario**: Acceso a perfil personal y rutinas

### 🏢 **Gestión Multi-Sede**

- Administración de múltiples ubicaciones
- Asignación de usuarios y coaches por sede
- Control de capacidad y estadísticas por ubicación

### 👥 **Gestión de Miembros**

- Base de datos completa de miembros
- Historial de check-ins y pagos
- Asignación de coaches y planes de entrenamiento
- Información médica y contactos de emergencia

### 💪 **Sistema de Entrenamientos**

- Base de datos con 50+ ejercicios organizados por grupo muscular
- 4 planes de entrenamiento predefinidos
- Generador de rutinas personalizadas
- Recomendaciones inteligentes por nivel y objetivos

### 🥗 **Gestión Nutricional**

- Planes nutricionales personalizados
- Seguimiento de comidas y macronutrientes
- Biblioteca de recetas saludables
- Integración con objetivos de entrenamiento

### 📊 **Reportes y Analíticas**

- Dashboard con métricas clave
- Análisis de ingresos y membresías
- Estadísticas de rendimiento por sede
- Alertas y notificaciones importantes

### 🤖 **Asistente IA Integrado**

- Chat inteligente contextual por rol
- Sugerencias de entrenamientos y nutrición
- Asistencia en tiempo real
- Respuestas personalizadas

## 🚀 Instalación

### Prerrequisitos

- Node.js (versión 18 o superior)
- npm, yarn o pnpm

### Pasos de Instalación

1. **Clonar el repositorio**

```bash
git clone https://github.com/tu-usuario/aurorafit.git
cd aurorafit
```

2. **Instalar dependencias**

```bash
npm install
# o
yarn install
# o
pnpm install
```

3. **Configurar variables de entorno**

```bash
cp .env.example .env.local
```

4. **Ejecutar en modo desarrollo**

```bash
npm run dev
# o
yarn dev
# o
pnpm dev
```

5. **Abrir en el navegador**

```
http://localhost:5173
```

## 🎯 Uso

### Credenciales de Prueba

| Rol               | Email               | Contraseña | Acceso                    |
| ----------------- | ------------------- | ---------- | ------------------------- |
| **Administrador** | admin@aurorafit.com | admin123   | Acceso completo           |
| **Coach**         | coach@aurorafit.com | coach123   | Gestión de entrenamientos |
| **Usuario**       | user@aurorafit.com  | user123    | Perfil personal           |

### Navegación Principal

#### Para Administradores:

- **Dashboard**: Métricas generales y accesos rápidos
- **Miembros**: Gestión completa de usuarios
- **Ubicaciones**: Administración de sedes
- **Reportes**: Analíticas y estadísticas
- **Entrenamientos**: Base de datos de ejercicios
- **Configuración**: Ajustes del sistema

#### Para Coaches:

- **Dashboard**: Vista general de clientes asignados
- **Entrenamientos**: Gestión de rutinas y ejercicios
- **Nutrición**: Planes nutricionales
- **Clientes**: Lista de miembros asignados
- **Perfil**: Información personal

#### Para Usuarios:

- **Dashboard**: Resumen personal de actividades
- **Entrenamientos**: Rutinas asignadas y progreso
- **Nutrición**: Plan nutricional personal
- **Historial**: Registro de actividades
- **Perfil**: Información y configuración personal

## 📁 Estructura del Proyecto

```
aurorafit/
├── public/
│   ├── assets/
│   │   ├── logos/          # Logos de AuroraFit
│   │   ├── images/         # Imágenes generales
│   │   └── icons/          # Iconos de la aplicación
│   ├── placeholder.svg     # Imagen placeholder
│   └── robots.txt
├── src/
│   ├── components/
│   │   └── ui/             # Componentes UI reutilizables
│   │       ├── dashboard-nav.tsx
│   │       ├── ai-assistant.tsx
│   │       └── ... (40+ componentes)
│   ├── hooks/              # Custom React hooks
│   │   ├── use-mobile.tsx
│   │   └── use-toast.ts
│   ├── lib/                # Utilities y configuración
│   │   ├── auth.ts         # Sistema de autenticación
│   │   ├── exercises.ts    # Base de datos de ejercicios
│   │   └── utils.ts        # Utilidades generales
│   ├── pages/              # Páginas de la aplicación
│   │   ├── Login.tsx
│   │   ├── Dashboard.tsx
│   │   ├── MemberManagement.tsx
│   │   ├── ExerciseRecommendations.tsx
│   │   └── ... (12+ páginas)
│   ├── App.tsx             # Componente principal y routing
│   ├── main.tsx            # Punto de entrada
│   └── index.css           # Estilos globales y variables Aurora
├── tailwind.config.ts      # Configuración de Tailwind con tema Aurora
├── vite.config.ts          # Configuración de Vite
└── package.json            # Dependencias y scripts
```

## 🎨 Sistema de Diseño Aurora

### Paleta de Colores

```css
/* Colores principales inspirados en aurora boreal */
:root {
  --aurora-green: #158d52; /* Verde aurora principal */
  --aurora-purple: #8b5cf6; /* Púrpura aurora */
  --aurora-blue: #3b82f6; /* Azul aurora */
  --aurora-pink: #ec4899; /* Rosa aurora */
  --aurora-accent: #10b981; /* Verde accent */
  --aurora-dark: #0f172a; /* Fondo oscuro */
}
```

### Clases CSS Personalizadas

- `.aurora-gradient`: Gradiente aurora principal
- `.aurora-card`: Tarjetas con efecto de cristal
- `.aurora-button-primary`: Botones con estilo aurora
- `.aurora-text-gradient`: Texto con gradiente aurora

## 🛠️ Tecnologías

### Frontend Core

- **React 18** - Biblioteca principal para UI
- **TypeScript** - Tipado estático
- **Vite** - Build tool y dev server
- **React Router DOM** - Enrutamiento SPA

### UI/UX

- **Tailwind CSS** - Framework de estilos utilitario
- **Radix UI** - Componentes primitivos accesibles
- **Framer Motion** - Animaciones fluidas
- **Lucide React** - Iconos modernos

### Gestión de Estado

- **TanStack Query** - Gestión de estado del servidor
- **React Hook Form** - Manejo de formularios
- **Zod** - Validación de esquemas

### Visualización de Datos

- **Recharts** - Gráficos y visualizaciones
- **React Three Fiber** - Elementos 3D (para efectos aurora)

### Herramientas de Desarrollo

- **ESLint** - Linting de código
- **Prettier** - Formateo automático
- **Vitest** - Testing framework

## 📦 Scripts Disponibles

```bash
# Desarrollo
npm run dev          # Servidor de desarrollo
npm run build        # Build de producción
npm run preview      # Preview del build

# Calidad de código
npm run typecheck    # Verificación de tipos
npm run format.fix   # Formateo automático
npm run test         # Ejecutar tests
```

## 🚀 Despliegue

### Build de Producción

```bash
npm run build
```

### Variables de Entorno Requeridas

```env
VITE_APP_NAME=AuroraFit
VITE_API_URL=https://api.aurorafit.com
VITE_STRIPE_PUBLIC_KEY=pk_live_...
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -m 'Añadir nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

## 🏆 Funcionalidades Destacadas

### 🎯 **Base de Datos de Ejercicios Completa**

- 50+ ejercicios categorizados por grupos musculares
- Instrucciones paso a paso con tips profesionales
- Niveles de dificultad (Principiante, Intermedio, Avanzado)
- Filtrado por equipo necesario

### 📱 **Diseño Responsive**

- Optimizado para escritorio, tablet y móvil
- Navegación adaptativa según el dispositivo
- Experiencia de usuario consistente en todas las plataformas

### 🔒 **Seguridad y Permisos**

- Sistema de roles granular
- Autenticación segura
- Control de acceso por ubicación
- Gestión de sesiones

### 📈 **Analytics Avanzados**

- Métricas en tiempo real
- Dashboards interactivos
- Reportes exportables
- Alertas automáticas

---

<p align="center">
  Desarrollado con ❤️ para la comunidad fitness
</p>

<p align="center">
  <strong>AuroraFit - Transformando la experiencia del gimnasio</strong>
</p>
