# 🎨 AuroraFit - Documentación de Assets

Este documento describe la organización y uso de todos los assets (imágenes, logos, iconos) utilizados en la aplicación AuroraFit.

## 📁 Estructura de Assets

```
public/assets/
├── logos/                    # Logos de AuroraFit
│   ├── aurorafit-logo.svg           # Logo principal (200x80)
│   ├── aurorafit-logo-compact.svg   # Logo compacto (60x60)
│   └── aurorafit-logo-white.svg     # Logo blanco (para fondos oscuros)
├── icons/                    # Iconos de la aplicación
│   ├── favicon.svg                  # Favicon principal (32x32)
│   ├── favicon-16x16.png           # Favicon PNG 16x16
│   └── favicon-32x32.png           # Favicon PNG 32x32
└── images/                   # Imágenes generales
    ├── gym-hero.svg                # Imagen hero del gimnasio (800x400)
    ├── avatar-placeholder.svg      # Avatar placeholder (150x150)
    ├── equipment/                  # Imágenes de equipamiento
    ├── nutrition/                  # Imágenes de nutrición
    └── backgrounds/               # Fondos y texturas
```

## 🏷️ Logos

### Logo Principal (`aurorafit-logo.svg`)

- **Dimensiones**: 200x80 píxeles
- **Uso**: Header principal, documentación, pantallas grandes
- **Características**:
  - Incluye icono de pesa estilizada
  - Texto "AURORA FIT" con gradiente aurora
  - Subtítulo "Sistema de Gestión"

### Logo Compacto (`aurorafit-logo-compact.svg`)

- **Dimensiones**: 60x60 píxeles
- **Uso**: Navegación móvil, botones pequeños, favicon grande
- **Características**:
  - Solo icono de pesa con letra "A"
  - Diseño circular con borde gradiente
  - Optimizado para tamaños pequeños

### Logo Blanco (`aurorafit-logo-white.svg`)

- **Dimensiones**: 200x80 píxeles
- **Uso**: Fondos oscuros, headers con fondo de color
- **Características**: Versión monocromática en blanco

## 🎯 Iconos

### Favicon (`favicon.svg`)

- **Dimensiones**: 32x32 píxeles
- **Formato**: SVG (escalable)
- **Uso**: Pestaña del navegador, bookmarks
- **Diseño**: Pesa simplificada en fondo gradiente aurora

### Favicons PNG

- **favicon-16x16.png**: Para compatibilidad con navegadores antiguos
- **favicon-32x32.png**: Versión de alta resolución

## 🖼️ Imágenes

### Hero del Gimnasio (`gym-hero.svg`)

- **Dimensiones**: 800x400 píxeles
- **Uso**: Página principal, banners, fondos de sección
- **Contenido**: Siluetas de equipamiento con efecto aurora

### Avatar Placeholder (`avatar-placeholder.svg`)

- **Dimensiones**: 150x150 píxeles
- **Uso**: Usuarios sin foto de perfil
- **Diseño**: Icono de usuario en gradiente aurora

## 🎨 Paleta de Colores en Assets

Todos los assets utilizan la paleta de colores oficial de AuroraFit:

```css
/* Colores principales */
--aurora-green: #158d52 /* Verde aurora principal */ --aurora-accent: #10b981
  /* Verde accent */ --aurora-blue: #3b82f6 /* Azul aurora */
  --aurora-purple: #8b5cf6 /* Púrpura aurora */ --aurora-pink: #ec4899
  /* Rosa aurora */ /* Colores neutrales */ --aurora-dark: #0f172a
  /* Fondo oscuro */ --aurora-gray: #374151 /* Gris para equipamiento */;
```

## 📋 Guías de Uso

### 1. **Logos**

- Usar logo principal en headers y documentación
- Usar logo compacto en espacios reducidos
- Mantener proporciones originales
- No modificar colores sin autorización

### 2. **Iconos**

- Favicon se aplica automáticamente en `index.html`
- Usar iconos consistentes con el tema aurora
- Priorizar SVG sobre formatos rasterizados

### 3. **Imágenes**

- Optimizar tamaños según el uso
- Mantener consistencia visual con la marca
- Usar placeholders cuando sea necesario

## 🔄 Assets Dinámicos

### Avatares de Usuario

Los avatares se cargan dinámicamente desde URLs externas (Unsplash) en el archivo `src/lib/auth.ts`:

```typescript
// Ejemplos de avatares utilizados
avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face";
```

### Fallback para Avatares

Cuando no hay avatar disponible, se usa `avatar-placeholder.svg` o las iniciales del usuario.

## ✅ Checklist de Assets

- [x] Logo principal SVG
- [x] Logo compacto SVG
- [ ] Logo blanco SVG
- [x] Favicon SVG
- [ ] Favicon PNG 16x16
- [ ] Favicon PNG 32x32
- [x] Imagen hero del gimnasio
- [x] Avatar placeholder
- [ ] Imágenes de equipamiento
- [ ] Imágenes de nutrición
- [ ] Fondos adicionales

## 🔧 Mantenimiento

### Añadir Nuevos Assets

1. Colocar en la carpeta correspondiente
2. Seguir convención de nombres descriptivos
3. Usar formato SVG cuando sea posible
4. Actualizar esta documentación
5. Verificar referencias en el código

### Optimización

- Usar herramientas como SVGO para optimizar SVGs
- Comprimir imágenes PNG/JPG sin perder calidad
- Considerar WebP para imágenes grandes
- Implementar lazy loading para imágenes no críticas

---

**Nota**: Esta documentación debe actualizarse cada vez que se añadan, modifiquen o eliminen assets del proyecto.
